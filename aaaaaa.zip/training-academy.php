<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">

<div data-elementor-type="wp-page" data-elementor-id="126" class="elementor elementor-126">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-58e73a5b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="58e73a5b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6eeb862b" data-id="6eeb862b" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1c338800 elementor-widget elementor-widget-text-editor" data-id="1c338800" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				&nbsp;
				
<div class="heading">
<h2>OUR TRAINING</h2>
</div>
<div class="content-message">
<ul class="list-styled">
 	<li>After recruitment untrained guards are trained by the Retd. Army J. c. o, s &amp; N. c. o.</li>
 	<li>Guards must be able to use fire remove and Fight backfire hazards. We offer you fall more dignified by the Royal Salutes of our smartly out guards at the doorstepping of our office safety is our insurance &amp; to hold your prestige is our assurance. Please do try us &amp; feel the difference.</li>
</ul>
</div>
<div class="heading">
<h2>Photo</h2>
</div>
[ngg_images source=&#8221;galleries&#8221; container_ids=&#8221;2&#8243; display_type=&#8221;photocrati-nextgen_basic_thumbnails&#8221; override_thumbnail_settings=&#8221;0&#8243; thumbnail_width=&#8221;240&#8243; thumbnail_height=&#8221;160&#8243; thumbnail_crop=&#8221;1&#8243; images_per_page=&#8221;20&#8243; number_of_columns=&#8221;4&#8243; ajax_pagination=&#8221;1&#8243; show_all_in_lightbox=&#8221;0&#8243; use_imagebrowser_effect=&#8221;0&#8243; show_slideshow_link=&#8221;0&#8243; slideshow_link_text=&#8221;[Show slideshow]&#8221; template=&#8221;default&#8221; order_by=&#8221;sortorder&#8221; order_direction=&#8221;ASC&#8221; returns=&#8221;included&#8221; maximum_entity_count=&#8221;500&#8243;]					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-3166b1a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3166b1a" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-27ee88b" data-id="27ee88b" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-205f652 elementor-widget elementor-widget-heading" data-id="205f652" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">SECURITY TRAINING</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-66d88ec elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="66d88ec" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Training</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Supervisor Training</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security In-Charge Training</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Zone Operation officer Training</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-f656cfc" data-id="f656cfc" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2b5d5e0 elementor-widget elementor-widget-heading" data-id="2b5d5e0" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">CLEANER TRAINING</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-b937c5c elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="b937c5c" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaner Training</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaner Supervisor Training </span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaner In-Charge Trainig</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Zone Operation Officer Training</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-1cd7b99" data-id="1cd7b99" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-398ab45 elementor-widget elementor-widget-heading" data-id="398ab45" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">PEST CONTROL TRAINING</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-3882164 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="3882164" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Pest Control Training </span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Pest Control Supervisor Training</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Pest Control In-Charge Training</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Zone Operation Officer Training</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
		
		<?php include('footer.php'); ?>