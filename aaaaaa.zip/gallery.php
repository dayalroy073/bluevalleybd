					<?php 
					include('header.php');
					?>


					<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-128994e.css?ver=1675022803">

<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">


<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">
<div data-elementor-type="wp-page" data-elementor-id="128" class="elementor elementor-128">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
					<style type="text/css">



						.myphotog{
	margin-left: 20px;
	margin-right: 20px;
	
}
	.myphotog img{
		margin-top: 20px;
		margin-bottom: 20px;

		}				@media screen and (min-width: 565px) {
  .mysex {
    margin-top: 200px;
  }





  @media screen and (min-width: 565px) {
  .myphotog{
    margin-left: auto;
    margin-right: auto;
    width: 900px;
  }
}

					</style>
									<section  class="mysex">


										
										<div class="myphotog">
											<h1>Photo Gallery</h1>


										 <img src="wp-content/uploads/2018/07/chairmana.jpg" width="100%">
										 <img src="wp-content/uploads/2018/07/zakariaa.jpg" width="100%">
										 <?php  


											for ($i = 1; $i <15 ; $i++) {
												?>



												<img src="wp-content/uploads/2023/2/<?php echo($i); ?>.jpg" width="100%">
												<?php 
											}
										 ?>
										  <img src="wp-content/uploads/2018/07/directora.jpg" width="100%">

										  <img src="wp-content/uploads/2018/07/director2a.jpg" width="100%">

										<img src="wp-content/uploads/2023/24/Imran Ahmed.jpg" width="100%">
										

										
										  </div>
						
		</section>
		
									</div>
			</div>
					</div>
					<?php 
					include('footer.php');
					?>