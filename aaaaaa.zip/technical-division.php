	<?php include('header.php'); ?>


<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-12451f1.css?ver=1675038447">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">

<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-124.css">







<div data-elementor-type="wp-page" data-elementor-id="124" class="elementor elementor-124">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-b8e0271 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b8e0271" data-element_type="section">
					<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-16f0649" data-id="16f0649" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ea231e3 elementor-widget elementor-widget-heading" data-id="ea231e3" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">TECHNICAL SECURITY</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c21e872 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="c21e872" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="td.php?page=1">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">CC Camra Service</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=2">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Drone</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=3">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Walkie Talkie</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=4">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Metal Detector</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=5">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Archway Gate</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=6">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Product Scanner Machine</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=7">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Dress</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=8">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Shoe</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=9">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Whistle</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=10">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Stick</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=11">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Umbrella</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=12">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Raincoat</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-b215643" data-id="b215643" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-3956e33 elementor-widget elementor-widget-heading" data-id="3956e33" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">TECHNICAL CLEANING</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-2988513 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="2988513" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="td.php?page=13">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Vacuum cleaner</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=14">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Scrubber</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=15">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">High-pressure washer</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=16">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Dryer </span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=17">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Glass cleaner </span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=18">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Glass Squeegee</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=19">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Dish Rack and Drainboard</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=20">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Tile, Sstone, Granite Cleaner</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=21">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Rubber Cleaning Gloevs</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-462cf3c" data-id="462cf3c" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-df7d9cc elementor-widget elementor-widget-heading" data-id="df7d9cc" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">TECHNICAL PEST CONTROL</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-5ec5600 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="5ec5600" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="td.php?page=22">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">BED BUG STEAMERS</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=23">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">B&amp;G sprayers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=24">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Backpack Sprayers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=25">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Power Sprayers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=26">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Dusters</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=27">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">IPM</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=28">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Foggers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=29">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Bait Guns</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="td.php?page=30">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Quality Pest Control Guns</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
					<?php include('footer.php'); ?>