<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">
<div class="main-body">
		<div class="container-fluid">
		
		<div class="container">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-8 col-lg-8">
					
					

										<div class="message-body">
				<h2>About us</h2>
				<div class="content-message">
					<p>Blue Valley Security service Limited., has been in the security industry for over a decade and has emerged as a leader and pace-setter. From its inception in 2000, Blue Valley Security service Limited. has grown rapidly and is currently over 22,500 strong and situated in every major region in Bangladesh.  Security personnel are being deployed in  all over the country. In terms of manpower,organizational setup, management & prompt response, Blue Valley Security service Limited. can be considered as the Best Security Company in Bangladesh. </p>

<h3>Our History</h3><p>
Mridul Hasan Sohag, the founder of Blue Valley Security service Limited. after gathering years of valuable experience in the infant security provider industry, crucially identified a key scarcity. The volatile nature of Bangladesh contributed to the burgeoning need for better, enhanced and professional security services. Blue Valley Security service Limited. was founded in 2000 by Mridul Hasan Sohag , with only 20 guards deployed in three organizations. Providing dedicated, sincere and passionate service along the way has endeared us to our clients and patrons alike.
</p>

<h3>Our Philosophy</h3>
Blue Valley Security service Limited. is a dynamic and versatile security company that has revolutionized the Security Guard Services in Bangladesh industry by applying strategies, techniques, and tactics that are responsive, effective, and highly efficient. We strive to develop our guards, operations, and management to be sensitive to our customers. Our customer focused approach has allowed us to truly understand the diversities and intricacies of their needs.

<h3>Our Clientele</h3>
Blue Valley Security service Limited. started out with only 5 clients back in 2015. Today the company boasts a clientele of over 1500 strong. Our diverse and venerable clientele encompass local, international and multinational organizations and concerns, medium to large corporate institutions, factories and foreign residents.

<h3>Our Expertise</h3>
At Blue Valley Security service Limited. (Blue Valley Security service Limited.) we provide complete security solutions. Our services include providing Security guards, Supervisors, Body Guards, Cash Carrying Services, Armed Guards, Female Security Personnel, Embassy Security, Traffic Control, Dog Squad, Sea Vessel Guarding, Vaulting, ATM Management, Background Checks/ Security Checks, Death claims/Medical Claims to just to name a few.

<h3>Our Affiliation</h3>
Blue Valley Security service Limited. is a member of ‘France-Bangladesh Chamber of Commerce and Industry’ and ‘Bangladesh Professional Security Services Providers Association’. Blue Valley Security service Limited. continuously evaluates the state of security situation in the country and determines the revised security needs of the localities.

<h3>Our Rise</h3>
<p>
Since inception the need for security has tripled all over the world and Bangladesh has been no different. To meet the growing demand, Blue Valley Security service Limited. stepped up to serve this great purpose. Today Blue Valley Security service Limited. has over 23,500 security guards & staffs deployed all over the country with more than 1350 clients (3100 posts). There are over 1100 security companies in Bangladesh today and Blue Valley Security service Limited. has emerged as a leader among them. Blue Valley Security service Limited. has been humbled and honored by this great acceptance by the people.
				</p>

				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					
										
				</div>
			</div>
		</div>

				

		</div>		
</div>

<?php include('footer.php'); ?>