	<!-- footer body ======================================================= -->
<footer>
		<div class="pull-container allbackground heading-jumbotron">
			<div class="container">
				<div class="footer">
					<div class="row">
						
						<div class="col-sm-12 col-md-3 col-lg-3">
							<h2>Important Link</h2>
							<hr>
							<ul class="list-styled">
								
								<li><a rel="nofollow" href="https://www.999.gov.bd/" target="_blank">National Emergency Service(Call:999)</a></li>
								<li><a rel="nofollow" href="http://www.rab.gov.bd/" target="_blank">Rapid Action Battalion(RAB)</a></li>
								<li><a rel="nofollow" href="https://www.bb.org.bd/" target="_blank">Bangladesh Bank</a></li>
								<li><a rel="nofollow" href="http://www.bangladeshyellowpages.com/" target="_blank">Bangladesh Yellow Pages</a></li>
								<li><a rel="nofollow" href="http://www.dip.gov.bd/" target="_blank">Immigration and Passports</a></li>
								<li><a rel="nofollow" href="http://www.epb.gov.bd/" target="_blank">Export Promotion Bureau (EPB)</a></li>
								<li><a rel="nofollow" href="http://www.police.gov.bd/" target="_blank">Bangladesh Police Head Quarters</a></li>
								<li><a rel="nofollow" href="http://www.educationboardresults.gov.bd/" target="_blank">Intermediate and Secondary Result</a></li>
								<li><a rel="nofollow" href="http://www.bangladesh.gov.bd/" target="_blank">Bangladesh Government Official Site</a></li>
								<li><a rel="nofollow" href="http://www.basis.org.bd/" target="_blank">BASIS</a></li>
							
		
							</ul>
						</div>

						<div class="col-sm-12 col-md-3 col-lg-3">
							<h2>Corporate Office</h2>
							<hr>
							<p>
								<i class="fa fa-map-marker"></i>
								<strong>Blue Valley Security service Limited</strong><br>
								  Sarkar Tower, <br>
219/6, Sultanganj Road, Hazaribagh, Dhaka-1209
							</p>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1291.2117837762555!2d90.36543478298253!3d23.74386903402017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bfb60140214b%3A0xe89743f3d78ff2b!2sSarkar%20Tower!5e0!3m2!1sbn!2sbd!4v1715967597519!5m2!1sbn!2sbd" width="100%" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
							
							<p>
								<i class="fa fa-phone"></i>
								<a href="tel:+8801958315700"><span Style="color: #fff;">+8801958315700</span></a>
							</p>
							<p>
								<i class="fa fa-phone"></i>
								<a href="tel:+8801911159592"><span Style="color: #fff;">+8801911159592</span></a>
							</p>
							<p>
								<i class="fa fa-envelope"></i>
								bluevallyltdbd@gmail.com
							</p>
							
							<p>
							<i class="fa fa-globe"></i>
							www.bluevalleybd.com
							</p>
						</div>
						
						<div class="col-sm-12 col-md-3 col-lg-3">
							<h2>Facebook Info</h2>
							<hr>
							<div class="content-message webFacebook">
							<div class="facebook-div">
								<!-- <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Ffsssltd&amp;width=450&amp;layout=standard&amp;action=like&amp;size=large&amp;show_faces=true&amp;share=true&amp;height=80&amp;appId=1627582737571085" width="100%" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe> -->
								<a href="https://www.facebook.com/profile.php?id=100090633927972"><img src="wp-content/uploads/2020/01/fb.png" width="100%" height="158px"></a>
							</div>
							
							</div>
						</div>
						<div class="col-sm-12 col-md-3 col-lg-3">
							<h2>QR-Code & Counter</h2>
							<hr>
							<div class="content-message webFacebook">
								<div id="qrcode" class="col-sm-12 col-md-12"><img src="wp-content/uploads/2020/01/qr-code-2-1.png"></div>
								
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
		<div class="pull-container  heading-jumbotron copyright">
			<div class="container">
				<div class="row">
						<div class="col-sm-12 col-md-6 col-lg-6">
							<p>Copyright  &copy; 2023, All right reserved www.bluevalleybd.com</p>
						</div>
						<div class="col-sm-12 col-md-6 col-lg-6 text-right">
							<p>Design & Developed by&nbsp;<b><a rel="nofollow" href="https://itcompanybd.com" target="_blank">www.itcompanybd.com </a></b></p>
						</div>
				</div>
			</div>
			
		</div>
	</footer>
	<link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer-legacy.min1f61.css?ver=4.2.17' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min6a4d.css?ver=6.1.1' type='text/css' media='all' />
<script type='text/javascript' src='wp-includes/js/jquery/jquery.mina7a0.js?ver=3.6.1' id='jquery-core-js'></script>
<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.mind617.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min1f61.js?ver=4.2.17' id='mediaelement-core-js'></script>
<script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-migrate.min6a4d.js?ver=6.1.1' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min6a4d.js?ver=6.1.1' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='wp-includes/js/mediaelement/renderers/vimeo.min1f61.js?ver=4.2.17' id='mediaelement-vimeo-js'></script>
</body>

</html>

