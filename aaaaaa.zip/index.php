<?php 
include('header.php');
?>

<div class="main-body">
				
<div class="pull-container">		
	<div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="2000">
		  <!-- Indicators -->
		  
		  <!-- Wrapper for slides -->
		  

		  <div class="carousel-inner" role="listbox">
        		            <div class="item active">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2020/01/Office-cleaning-services.png" class="img-responsive wp-post-image" alt="Office-cleaning-services"  />		              
		              	
		            </div>
				           
				            <div class="item ">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2020/01/Security-Equipment.png" class="img-responsive wp-post-image" alt="Security Equipment" />		              
		              	
		            </div>
				            <div class="item ">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2020/01/Security-agency-1.png" class="img-responsive wp-post-image" alt="Security-agency"  />		              
		              	
		            </div>
				            <div class="item ">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2018/08/Security-Guard-1.png" class="img-responsive wp-post-image" alt="Security-Guard Slider 01"  />		              
		              	
		            </div>
				            <div class="item ">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2018/08/a.png" class="img-responsive wp-post-image" alt="Our Service"  />		              
		              	
		            </div>
				            <div class="item ">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2018/08/W03.jpg" class="img-responsive wp-post-image" alt="Pictures"  />		              
		              	
		            </div>
				            <div class="item ">
		              
		              		<img width="1750" height="600" src="wp-content/uploads/2020/01/Pest-control-services.png" class="img-responsive wp-post-image" alt="Pest-control-services"  />		              
		              	
		            </div>
		        </div>
		  
		  
		  <!-- Left and right controls -->
		  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
			<span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#myCarousel" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
			<span class="sr-only">Next</span>
		  </a>
	</div>
</div>
			
			<div class="container-fluid">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-8 col-lg-8">
					


<div class="message-body">
	<h2>Our Client</h2>
	<div class="clientlogo">
		<div id="thumbnail-slider">
				<div class="inner">
					<ul>
											<li>
						<img width="50" height="60" src="wp-content/uploads/2018/08/GM_logo_web-100x120_550x.png" class="thumb img-responsive wp-post-image" alt="security company"  />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="1387" height="441" src="wp-content/uploads/2020/01/AESERealEstate.png" class="thumb img-responsive wp-post-image" alt=""  />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="180" height="60" src="wp-content/uploads/2018/08/myone.png" class="thumb img-responsive wp-post-image" alt="security guard agency"/>									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="1903" height="594" src="wp-content/uploads/2020/01/scandex-knitwear-ltd.png" class="thumb img-responsive wp-post-image" alt="" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="78" height="60" src="wp-content/uploads/2018/08/logo-1.png" class="thumb img-responsive wp-post-image" alt="security" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="500" height="300" src="wp-content/uploads/2020/01/Untitled-13.png" class="thumb img-responsive wp-post-image" alt="" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="226" height="60" src="wp-content/uploads/2018/08/slogo.png" class="thumb img-responsive wp-post-image" alt="guard agency"  />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="357" height="200" src="wp-content/uploads/2020/01/download.png" class="thumb img-responsive wp-post-image" alt=""  />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="148" height="60" src="wp-content/uploads/2018/08/logso.png" class="thumb img-responsive wp-post-image" alt="Security Services" decoding="async" loading="lazy" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="200" height="200" src="wp-content/uploads/2018/09/final-1.png" class="thumb img-responsive wp-post-image" alt="security services" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="94" height="89" src="wp-content/uploads/2018/08/506536_1f4e97d72be34855a5c69af1291825acmv2.jpg" class="thumb img-responsive wp-post-image" alt="best security company" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="600" height="461" src="wp-content/uploads/2018/09/WeChat-Image_20180609131224.png" class="thumb img-responsive wp-post-image" alt="" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="600" height="420" src="wp-content/uploads/2020/01/Daeyu-Bangla-PNG-logo.png" class="thumb img-responsive wp-post-image" alt="Shohag security service client," />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="200" height="200" src="wp-content/uploads/2020/01/dongjin-logo.png" class="thumb img-responsive wp-post-image" alt=""/>									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="225" height="225" src="wp-content/uploads/2020/01/mk.png" class="thumb img-responsive wp-post-image" alt=""  />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="106" height="60" src="wp-content/uploads/2018/08/1528086449.png" class="thumb img-responsive wp-post-image" alt="Akh Group" decoding="async" loading="lazy" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="200" height="200" src="wp-content/uploads/2020/01/woolen-Wool-Ltd1.png" class="thumb img-responsive wp-post-image" alt=""  />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="70" height="60" src="wp-content/uploads/2018/08/ug_logo.png" class="thumb img-responsive wp-post-image" alt="guard agency" decoding="async" loading="lazy" />									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="900" height="480" src="wp-content/uploads/2020/01/Simeens-Logo.png" class="thumb img-responsive wp-post-image" alt="" decoding="async"/>									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="653" height="200" src="wp-content/uploads/2020/01/sky-Line.png" class="thumb img-responsive wp-post-image" alt="" decoding="async"/>									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="51" height="60" src="wp-content/uploads/2018/08/swanlon-logo.png" class="thumb img-responsive wp-post-image" alt="guard agency"/>									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="500" height="300" src="wp-content/uploads/2020/01/unnamed-file.png" class="thumb img-responsive wp-post-image" alt="" decoding="async"/>									<a class="thumb" href="#"></a>
						</li>
												<li>
						<img width="160" height="152" src="wp-content/uploads/2018/08/hl_logo_con.jpg" class="thumb img-responsive wp-post-image" alt="security company" decoding="async" loading="lazy" />									<a class="thumb" href="#"></a>
						</li>
											
											</ul>
				</div>
			</div>
	
	</div>
</div>
<script>
	$(document).ready(function() {
			$('#LogoCarousel').carousel({
			interval: 300
			})
			
			$('#LogoCarousel').on('slid.bs.carousel', function() {
				//alert("slid");
			});
			
			
		});
	</script>		
			<div class="message-body">
				<h2>Chairman:Abdullah Al Zayed</h2>
				<div class="content-message">
				<img width="150" height="170" src="img/ch1.jpg" class="img-thumbnail message-image wp-post-image" alt="chairman talukder" decoding="async" loading="lazy" />
				<p>Blue Valley Security Service Limited is a premier security service company in Bangladesh, providing top-notch security services to clients across the country. Our Chairman, Abdullah Al Zayed, leads our dedicated team of security professionals with a commitment to excellence and a passion for ensuring the safety and security of our clients.</p>
<p>At Blue Valley Security Service Limited, we understand the importance of security in today's world. We offer a comprehensive range of security services, including manned guarding, electronic security, risk assessment, and security consultancy services. Our services are tailored to meet the specific needs of our clients, ensuring that they receive the highest level of protection at all times.</p>
<p>One of our core strengths is our team of highly trained and experienced security professionals. Our security personnel are selected based on their expertise, professionalism, and ability to work in a team. We provide them with regular training to ensure that they are up-to-date with the latest security techniques and technologies.</p>
<p>Our commitment to excellence has earned us a reputation as one of the most reliable security service providers in Bangladesh. We have a proven track record of providing quality services to a wide range of clients, including government organizations, multinational companies, and small businesses.</p>
<p>At Blue Valley Security Service Limited, we take pride in our ability to provide customized security solutions to our clients. We work closely with our clients to understand their unique security requirements and develop tailor-made solutions to meet their needs. We believe that this approach enables us to provide the most effective security services and ensures that our clients receive the highest level of protection.</p>
<p>Our Chairman, Abdullah Al Zayed, has played a pivotal role in the success of Blue Valley Security Service Limited. His leadership and vision have enabled us to grow and expand our services, while maintaining our commitment to excellence. Under his guidance, we have become one of the most trusted security service providers in Bangladesh.</p>
<p>In conclusion, Blue Valley Security Service Limited is a leading security service company in Bangladesh, providing top-notch security services to clients across the country. Our commitment to excellence, combined with our team of highly trained and experienced security professionals, enables us to provide the highest level of protection to our clients. With Chairman Abdullah Al Zayed leading our team, we are confident that we will continue to grow and expand our services, while maintaining our commitment to excellence.</p>
				</div>
			</div>
		
				
			<div class="message-body">
				<h2>MANAGING DIRECTOR Zakaria Hawladar</h2>
				<div class="content-message">
				<img width="200" height="200" src="za.jpeg" class="img-thumbnail message-image wp-post-image" alt="Managing Director Md Retired Army Comrade Captain Zakaria"/>


				<p>Blue Valley Security Service Limited is a reputable security service company in Bangladesh, known for providing top-notch security services to clients across the country. Our Managing Director, Zakaria Hawladar, leads our team of highly trained and experienced security professionals, and his expertise in team management has been instrumental in our success.</p>
<p>At Blue Valley Security Service Limited, we believe that effective team management is essential to providing high-quality security services. We understand that our security personnel are the backbone of our organization, and their expertise and professionalism are essential to our success. Our Managing Director, Zakaria Hawladar, has extensive experience in team management, and he ensures that our team of security professionals works cohesively to provide the highest level of protection to our clients.</p>
<p>One of our core strengths is our ability to provide customized security solutions to our clients. We work closely with our clients to understand their unique security requirements and develop tailor-made solutions to meet their needs. Our team of security professionals is highly trained and experienced, and they are equipped with the latest security techniques and technologies to provide effective protection to our clients.</p>
<p>At Blue Valley Security Service Limited, we understand that security threats are constantly evolving, and we are committed to staying ahead of the curve. We invest in the latest security technologies and regularly provide our security personnel with training to ensure that they are up-to-date with the latest security techniques and technologies.</p>
<p>Our Managing Director, Zakaria Hawladar, plays a crucial role in ensuring that we provide the highest quality of security services to our clients. He is committed to excellence and ensures that our team of security professionals is equipped with the necessary skills and resources to provide effective protection to our clients.</p>
<p>At Blue Valley Security Service Limited, we take pride in our ability to provide reliable and efficient security services to our clients. We are committed to meeting our clients' needs and exceeding their expectations.
				</div>
			</div>
		
				
			<div class="message-body">
				<h2>Director:Retired Army Comrade Captain Zakaria “Bengal Regiment </h2>
				<div class="content-message">
				<img width="150" height="170" src="wp-content/uploads/2018/07/directora.jpg" class="img-thumbnail message-image wp-post-image" alt="Mridol Hasan Shohag"  />Blue Valley Security Service Limited Providing Top-Notch Security Services in Bangladesh

When it comes to security, you want to make sure you're working with a company you can trust. Blue Valley Security Service Limited is a leading security service provider in Bangladesh, offering a wide range of security solutions to individuals and businesses alike. Led by director Zakaria, a retired army Comrade Captain who served in the Bengal Regiment, the company has become a trusted name in the industry.

With Zakaria's leadership, Blue Valley Security Service Limited has quickly established itself as a premier security service company in Bangladesh. Zakaria's background in the military, where he served as a Comrade Captain in the Bangladesh Army, has given him the experience and knowledge necessary to provide top-notch security services. His experience and leadership have allowed Blue Valley Security Service Limited to provide security solutions tailored to the specific needs of each client.
				</div>
			</div>


						<div class="message-body">
				<h2>Director:Retired Brigadier General Redwan (Bengal Regiment)</h2>
				<div class="content-message">
				<img width="150" height="170" src="wp-content/uploads/2018/07/director2a.jpg" class="img-thumbnail message-image wp-post-image" alt="Mridol Hasan Shohag"  />	<p>Blue Valley Security Service Limited is a leading security services company in Bangladesh. The company provides a wide range of security services including security guards, CCTV surveillance, access control, event security, and more.</p>

<p>The company is led by Director Redwan, a retired Brigadier General of the Bangladesh Regiment. With his 30+ years of experience in the military, Director Redwan has instilled a culture of discipline, professionalism, and dedication in the company's operations.</p>

<p>Blue Valley Security Service Limited is located at 97/B (Chand Plaza), Malibag Chowdhurypara in Dhaka-1219. The office is strategically located to serve clients in the Dhaka area and beyond. Clients can contact the company through their email address, bluevallyltdbd@gmail.com or by calling their phone number at +8801953580854.
</p><p>
The company has a team of highly trained security personnel who undergo rigorous training to ensure they are up to the task. The security guards are trained in crowd control, access control, emergency response, and more. The CCTV surveillance team is trained in monitoring and responding to security threats while the event security team is trained in providing a safe and secure environment for events.
</p> <p>
Blue Valley Security Service Limited is committed to providing its clients with top-notch security services that meet and exceed their expectations. The company uses the latest technology to ensure that its clients' properties are safe and secure. Whether it's a commercial or residential property, the company has the expertise and experience to provide customized security solutions.
</p><p>
In conclusion, Blue Valley Security Service Limited is a reliable and trustworthy security services company in Bangladesh. With Director Redwan's leadership and the company's commitment to excellence, clients can rest assured that their properties are in safe hands.</p>
				</div>
			</div>
		
							
					
				<div class="message-body">
						<h2>our vision</h2>
						<div class="content-message">
							<p>Blue Valley Security service Limited. employs over 1400 people and has a diverse workforce that includes home guards, lady security guards, and former arm force personnel. The company has a reputation for providing professional and reliable security services and is committed to providing job opportunities to those who are looking for a career in the security industry.</p><p>

At Blue Valley Security service Limited., the safety and security of clients is of utmost importance. The company's security personnel undergo rigorous training to ensure that they are equipped to handle any security-related situation. The company has a 24/7 control room that ensures prompt response times and efficient management of security services.</p><p>

In conclusion, Blue Valley Security service Limited. is a leading security services company in Bangladesh that is dedicated to providing top-quality security services to its clients. With a team of experienced and well-trained security personnel, the company has established itself as a trusted name in the security industry. Whether you are looking for home security, commercial security, or industrial security services, Blue Valley Security service Limited. is the right choice for you.</p>Blue Valley Security service Limited. is a reliable and professional security company that is dedicated to providing a safe and secure environment for its clients. The company's commitment to excellence is reflected in its management and organizational setup, which ensures that the company's services are of the highest quality. The company's focus on continuous training and development of its security personnel ensures that its clients receive the best possible services.

The company's clients can trust that Blue Valley Security service Limited. will provide them with a comprehensive security solution that is tailored to their specific needs. Whether it's providing security for residential properties, commercial establishments, or industrial sites, the company has the expertise and resources to provide a complete security solution.

In addition to its security services, Blue Valley Security service Limited. is also committed to providing job opportunities to those who are interested in a career in the security industry. The company offers its employees competitive salaries, benefits, and training opportunities, which helps them to grow both professionally and personally.

Overall, Blue Valley Security service Limited. is a company that is dedicated to providing top-quality security services and is committed to providing a safe and secure environment for its clients. With a team of experienced and well-trained security personnel, the company has established itself as a trusted name in the security industry. If you're looking for a reliable and professional security company, look no further than Blue Valley Security service Limited..</p>





						</div>
				</div>
					
			</div>
<div class="col-sm-12 col-md-4 col-lg-4">
										
<div class="content-message-sidebar"><h2>Security Gard</h2><div style="width:100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement('video');</script><![endif]-->

 <img  style="margin-top:10px; border:2px solid black;" src="wp-content/uploads/2023/24/gard/1a.jpg" width="100%">
  <!--<img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/1.jpg" width="100%">-->
   <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/2a.jpg" width="100%">
    <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/3a.jpg" width="100%">
        <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/4a.jpg" width="100%">
          <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/5.jpg" width="100%">
   <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/6.jpg" width="100%">
    <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/7.jpg" width="100%">
    <img  style="margin-top:10px; border:2px solid black;" src="wp-content/uploads/2023/24/gard/8.jpg" width="100%">
  <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/9.jpg" width="100%">
   <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/10.jpg" width="100%">
    <img style="margin-top:10px; border:2px solid black;"  src="wp-content/uploads/2023/24/gard/11.jpg" width="100%">
</div>
</div>
</div>						
										
			</div>
				
		</div>		
	</div>	
<?php 
include('footer.php');
?>