<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">



<div class="main-body">
		<div class="container-fluid">
		

<div class="row margin-top">
				<div class="col-sm-12 col-md-12 col-lg-12">
				
					<div class="heading">
							<h2 style="border-right: 5px solid #FDCC09;text-align: center;">OUR CERTIFICATION</h2>
					</div>
					<div class="certification">
							
						
						  								
								<div class="content-message">
								
								<a href="#" title="Certificate 09" target="_blank">
								
									<img width="1190" height="1684" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 1190px) 100vw, 1190px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="#" title="Certificate 10" target="_blank">
								
									<img width="595" height="842" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 595px) 100vw, 595px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="#" title="Certificate 01" target="_blank">
								
									<img width="1190" height="1684" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 1190px) 100vw, 1190px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-02/index.html" title="Certificate 02" target="_blank">
								
									<img width="595" height="842" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 595px) 100vw, 595px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-03/index.html" title="Certificate 03" target="_blank">
								
									<img width="595" height="842" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="VAT certification" decoding="async" loading="lazy" sizes="(max-width: 595px) 100vw, 595px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-04/index.html" title="Certificate 04" target="_blank">
								
									<img width="1190" height="1684" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 1190px) 100vw, 1190px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-05/index.html" title="Certificate 05" target="_blank">
								
									<img width="1190" height="1684" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 1190px) 100vw, 1190px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-06/index.html" title="Certificate 06" target="_blank">
								
									<img width="1190" height="1684" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 1190px) 100vw, 1190px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-07/index.html" title="Certificate 07" target="_blank">
								
									<img width="595" height="842" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 595px) 100vw, 595px">								</a>
								
								</div>
								
								
																
								<div class="content-message">
								
								<a href="../certificate-08/index.html" title="Certificate 08" target="_blank">
								
									<img width="595" height="842" src="wp-content/uploads/2020/01/cira.jpg" class="img-responsive wp-post-image" alt="" decoding="async" loading="lazy" sizes="(max-width: 595px) 100vw, 595px">								</a>
								
								</div>
								
								
															 
							  
								

						
					</div>
				</div>
                <!--
				<div class="col-sm-12 col-md-4 col-lg-4">
					
										
				</div>-->
</div>			

		</div>		
</div>
<?php include('footer.php'); ?>