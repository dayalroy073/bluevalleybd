	<?php include('header.php'); ?>


<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global.css">


<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-124.css">
	<div data-elementor-type="wp-page" data-elementor-id="124" class="elementor elementor-124">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-b8e0271 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b8e0271" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-16f0649" data-id="16f0649" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ea231e3 elementor-widget elementor-widget-heading" data-id="ea231e3" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">TECHNICAL SECURITY</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c21e872 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="c21e872" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="/cctv-camera/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">CC Camra</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/drone/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Drone</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/walkie-talkie/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Walkie Talkie</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/metal-detector/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Metal Detector</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/product-scanner-machine/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Archway Gate</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/security-flashlight/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Product Scanner Machine</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/security-guard-dress/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Dress</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/boot-shoe/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Shoe</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/security-whistle/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Whistle</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/security-stick/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Stick</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/security-guard-umbrella/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Umbrella</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/security-guard-raincoat/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard Raincoat</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-b215643" data-id="b215643" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-3956e33 elementor-widget elementor-widget-heading" data-id="3956e33" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">TECHNICAL CLEANING</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-2988513 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="2988513" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="/vacuum-cleaner/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Vacuum cleaner</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/floor-scrubbers/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Scrubber</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/high-pressure-washer/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">High-pressure washer</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/dryer-and-dryer-sheet/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Dryer </span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/glass-cleaner/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Glass cleaner </span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/glass-squeegee/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Glass Squeegee</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/dish-rack-and-drainboard-cleaning/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Dish Rack and Drainboard</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/tile-stone-granite-cleaner/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Tile, Sstone, Granite Cleaner</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/rubber-cleaning-gloves/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Rubber Cleaning Gloevs</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-462cf3c" data-id="462cf3c" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-df7d9cc elementor-widget elementor-widget-heading" data-id="df7d9cc" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">TECHNICAL PEST CONTROL</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-5ec5600 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="5ec5600" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="/bed-bug-steamers/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">BED BUG STEAMERS</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/bg-sprayers/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">B&G sprayers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/backpack-sprayers/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Backpack Sprayers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/power-sprayers/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Power Sprayers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/duster/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Dusters</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">IPM</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/pesticides-foggers/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Foggers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/bait-guns/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Bait Guns</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="/bait-guns/index.html">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Quality Pest Control Guns</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
					<?php include('footer.php'); ?>