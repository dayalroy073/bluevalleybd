<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">
<div class="main-body">
		<div class="container-fluid">
		
		<div class="container">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-8 col-lg-8">
					
					
<article id="post-132" class="post-132 page type-page status-publish hentry">

												
						<div class="entry-content">
									<div data-elementor-type="wp-page" data-elementor-id="132" class="elementor elementor-132">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-2116f811 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2116f811" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-67acb7c3" data-id="67acb7c3" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-1350ba6 elementor-widget elementor-widget-shortcode" data-id="1350ba6" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode">
						<h1>Contact us</h1>

						<form method="post">
							<style type="text/css">
								input{
									width: 300px;
									height: 40px;
									padding: 5px;
								}
							</style>
							<table>
								<tr>
									<td><label>Name:</label></td>
									<td><input type="text" name="" placeholder="Full name"></td>
								</tr>
																<tr>
									<td><label>Email:</label></td>
									<td><input type="text" name="" placeholder="email"></td>
								</tr>
																<tr>
									<td><label>Phone:</label></td>
									<td><input type="text" name="" placeholder="phone number"></td>
								</tr>
																<tr>
									<td><label>Text:</label></td>
									<td><input type="text" name="" placeholder="your message"></td>
								</tr>
							</table>
							<input type="submit" name="" value="Submit">
						</form>
					</div>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
								</div><!-- .entry-content -->
					</article>
				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					
										
				</div>
			</div>
		</div>

				

		</div>		
</div>

<?php include('footer.php'); ?>