<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">


<div class="main-body">
		<div class="container-fluid">
		

<div class="row margin-top">
				<div class="col-sm-12 col-md-12 col-lg-12">
				
					<div class="heading">
							<h2>APPOINTMENT CIRCULAR </h2>
					</div>
					<div class="content-message">
								<ul class="list-styled">
									<li>After recruitment untrained guards are trained by the Retd. Army J. c. o, s &amp; N. c. o. </li>
									<li>Guards must be able to use fire remove and Fight backfire hazards. We offer you fall more dignified by the Royal Salutes of our smartly out guards at the door stepping of our office safety is our insurance &amp; to hold your prestige is our assurance. Please do try us &amp; feel the difference. </li>
								</ul>
                                <img width="2380" height="3368" src="wp-content/uploads/2020/02/circular.jpg" class="img-responsive wp-post-image" alt="Career guideline" >					</div>
					<table class="table table-bordered">
						<thead>
								<tr>
								  <th>Job Title</th>
								  <th>Description</th>
								  
								</tr>
						</thead>
						<tbody>
															
						</tbody>
					</table>
					
				</div>
				
</div>			

		</div>		
</div>
<?php include('footer.php'); ?>