<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">


<div data-elementor-type="wp-page" data-elementor-id="4367" class="elementor elementor-4367">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-73d37b8a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="73d37b8a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-12a3de9" data-id="12a3de9" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-f80b517 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f80b517" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-cc4fce4" data-id="cc4fce4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-55b1cae elementor-widget elementor-widget-spacer" data-id="55b1cae" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-e083b5a elementor-widget elementor-widget-heading" data-id="e083b5a" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-default">SO FRESH &amp; SO CLEAN WE PROMISE
</h1>		</div>
				</div>
				<div class="elementor-element elementor-element-1b5779b elementor-widget elementor-widget-text-editor" data-id="1b5779b" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-b533ea8 elementor-button-info elementor-align-left elementor-widget elementor-widget-button" data-id="b533ea8" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#service" class="elementor-button-link elementor-button elementor-size-sm elementor-animation-grow" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Get Services</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-bfe8851" data-id="bfe8851" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ddd2ba8 elementor-widget elementor-widget-image" data-id="ddd2ba8" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" width="900" height="602" src="wp-content/uploads/2021/04/wall-paintng.jpg" class="attachment-large size-large wp-image-4414" >														</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-79ac5fc8 elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="79ac5fc8" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4c9b009f" data-id="4c9b009f" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-7acbde10 elementor-widget elementor-widget-heading" data-id="7acbde10" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h3 class="elementor-heading-title elementor-size-large">About Us</h3>		</div>
				</div>
				<div class="elementor-element elementor-element-2d4e0bb9 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="2d4e0bb9" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-5cef075 elementor-widget elementor-widget-heading" data-id="5cef075" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Clean Home Bringing Excellence in Residential &amp; Commercial cleaning services</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-5ae1e06 elementor-widget elementor-widget-text-editor" data-id="5ae1e06" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<div class="ht-content lz-about-text">We offer a wide range of cleaning services to fit your needs and suit your schedule. Our team members are fully trained and highly motivated individuals who want you to come home to a safe and healthy environment. We provide cleaning services to you professionally and efficiently. You will be confident in the knowledge that your family’s health and safety are our top priority.</div><div>&nbsp;</div><div class="ht-content lz-about-text"><ul><li>Cleaning Services System.</li><li>Carpet Cleaning Instrument.</li><li>Residential Cleaning Service.</li></ul></div>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-52b7236 elementor-widget elementor-widget-button" data-id="52b7236" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#reviews" class="elementor-button-link elementor-button elementor-size-sm elementor-animation-grow" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Check Customer Reviews</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-11767b86" data-id="11767b86" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-50dc7be elementor-widget elementor-widget-image" data-id="50dc7be" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" width="900" height="900" src="wp-content/uploads/2021/04/cleaning-2.png" class="attachment-full size-full wp-image-4406" >														</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-61479f81 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="61479f81" data-element_type="section" id="service">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1d78e35a" data-id="1d78e35a" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-54d43e99 elementor-widget elementor-widget-heading" data-id="54d43e99" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-large">Our Services
</h1>		</div>
				</div>
				<div class="elementor-element elementor-element-e8da0d7 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="e8da0d7" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-4ff28b85 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4ff28b85" data-element_type="section">
						<div class="elementor-container elementor-column-gap-wider">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-20e62163" data-id="20e62163" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-17f91c9 elementor-vertical-align-middle elementor-position-top elementor-widget elementor-widget-image-box" data-id="17f91c9" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="128" height="128" src="wp-content/uploads/2021/04/1470399662_Marketing.png" class="attachment-full size-full wp-image-4389" ></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Apartment Cleaning</h3><p class="elementor-image-box-description">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec mattis, pulvinar dapibus leo.</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-6bb2aff elementor-vertical-align-middle elementor-position-top elementor-widget elementor-widget-image-box" data-id="6bb2aff" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="128" height="128" src="wp-content/uploads/2021/04/1470399662_Marketing.png" class="attachment-full size-full wp-image-4389"></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Commercial Cleaning</h3><p class="elementor-image-box-description">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec mattis, pulvinar dapibus leo.</p></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-35dd1b2b" data-id="35dd1b2b" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-36d5277a elementor-vertical-align-middle elementor-position-top elementor-widget elementor-widget-image-box" data-id="36d5277a" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="128" height="128" src="wp-content/uploads/2021/04/1470399662_Marketing.png" class="attachment-full size-full wp-image-4389"></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Maid Cleaning</h3><p class="elementor-image-box-description">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec mattis, pulvinar dapibus leo.</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-55d7f0b elementor-vertical-align-middle elementor-position-top elementor-widget elementor-widget-image-box" data-id="55d7f0b" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="128" height="128" src="wp-content/uploads/2021/04/1470399662_Marketing.png" class="attachment-full size-full wp-image-4389" ></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Carpet Cleaning</h3><p class="elementor-image-box-description">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec mattis, pulvinar dapibus leo.</p></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7ee7fcd" data-id="7ee7fcd" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2b004c2 elementor-vertical-align-middle elementor-position-top elementor-widget elementor-widget-image-box" data-id="2b004c2" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="128" height="128" src="wp-content/uploads/2021/04/1470399662_Marketing.png" class="attachment-full size-full wp-image-4389" ></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Door Cleaning</h3><p class="elementor-image-box-description">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec mattis, pulvinar dapibus leo.</p></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-81eabba elementor-vertical-align-middle elementor-position-top elementor-widget elementor-widget-image-box" data-id="81eabba" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="128" height="128" src="wp-content/uploads/2021/04/1470399662_Marketing.png" class="attachment-full size-full wp-image-4389" ></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title">Kitchen  Cleaning</h3><p class="elementor-image-box-description">Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec mattis, pulvinar dapibus leo.</p></div></div>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-a3c6721 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a3c6721" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a511362" data-id="a511362" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ad0b7d5 elementor-widget elementor-widget-heading" data-id="ad0b7d5" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-large">management facility experts
</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-da08f9a elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="da08f9a" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-bf97fd9 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="bf97fd9" data-element_type="section">
						<div class="elementor-container elementor-column-gap-wider">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6d74881" data-id="6d74881" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-40f3f2c elementor-widget elementor-widget-image" data-id="40f3f2c" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-404c2aa elementor-widget elementor-widget-heading" data-id="404c2aa" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-eefee6a elementor-widget elementor-widget-text-editor" data-id="eefee6a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Home Appliances</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-742f263" data-id="742f263" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2c26373 elementor-widget elementor-widget-image" data-id="2c26373" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-8cb2740 elementor-widget elementor-widget-heading" data-id="8cb2740" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c3614cf elementor-widget elementor-widget-text-editor" data-id="c3614cf" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Painter</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2a615c7" data-id="2a615c7" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-dae82f8 elementor-widget elementor-widget-image" data-id="dae82f8" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-e3afd97 elementor-widget elementor-widget-heading" data-id="e3afd97" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-644e8e4 elementor-widget elementor-widget-text-editor" data-id="644e8e4" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Pest Control</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-bf2abbe" data-id="bf2abbe" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-35822b5 elementor-widget elementor-widget-image" data-id="35822b5" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-2215b21 elementor-widget elementor-widget-heading" data-id="2215b21" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-65416c0 elementor-widget elementor-widget-text-editor" data-id="65416c0" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Cleaning</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-397fe98 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="397fe98" data-element_type="section">
						<div class="elementor-container elementor-column-gap-wider">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4b602b0" data-id="4b602b0" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-612aae2 elementor-widget elementor-widget-image" data-id="612aae2" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-c8d331c elementor-widget elementor-widget-heading" data-id="c8d331c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-fa77db2 elementor-widget elementor-widget-text-editor" data-id="fa77db2" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Electric &amp; Plumbing</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b55565d" data-id="b55565d" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ff36e96 elementor-widget elementor-widget-image" data-id="ff36e96" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-ef9da94 elementor-widget elementor-widget-heading" data-id="ef9da94" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-d4bf2ea elementor-widget elementor-widget-text-editor" data-id="d4bf2ea" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Cleaning</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3613de3" data-id="3613de3" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-41901f4 elementor-widget elementor-widget-image" data-id="41901f4" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-d0f9574 elementor-widget elementor-widget-heading" data-id="d0f9574" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-17e3fb0 elementor-widget elementor-widget-text-editor" data-id="17e3fb0" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Cleaning</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-ce81541" data-id="ce81541" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-e4fcee7 elementor-widget elementor-widget-image" data-id="e4fcee7" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" src="wp-content/plugins/elementor/assets/images/placeholder.png" title="" >														</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-99885f6 elementor-widget elementor-widget-heading" data-id="99885f6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Name</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-a2d539b elementor-widget elementor-widget-text-editor" data-id="a2d539b" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Cleaning</p>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-55b9ed51 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="55b9ed51" data-element_type="section" id="reviews">
						<div class="elementor-container elementor-column-gap-no">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5b86ba6f" data-id="5b86ba6f" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5785802 elementor-widget elementor-widget-heading" data-id="5785802" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-default">Customer Felling's </h1>		</div>
				</div>
				<div class="elementor-element elementor-element-1c3aad9 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="1c3aad9" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-26c7dd7 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="26c7dd7" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d1990f4" data-id="d1990f4" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-21e2bcd elementor-widget elementor-widget-image" data-id="21e2bcd" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" width="600" height="600" src="wp-content/uploads/2021/04/profile.jpg" class="attachment-full size-full wp-image-4417" >														</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5e8d755" data-id="5e8d755" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-928795f elementor-view-default elementor-widget elementor-widget-icon" data-id="928795f" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="fas fa-quote-left"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-e5ccde7 elementor-widget elementor-widget-text-editor" data-id="e5ccde7" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<p>Let me say something. You have an amazing theme and amazing/awesome support. They helped me on weekend. This is what I call an “extra mile” in customer relationship. So I gave 5 stars for the theme and if I could, I’d give 10 stars for support.</p>					</div>
						</div>
				</div>
				<div class="elementor-element elementor-element-9ed2d5d elementor-widget elementor-widget-heading" data-id="9ed2d5d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Mike Stuart</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-ec7ef12 elementor-widget elementor-widget-heading" data-id="ec7ef12" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Head of Sales , Intel</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2a01a40d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2a01a40d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2317c9b6" data-id="2317c9b6" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-5090a267 elementor-widget elementor-widget-heading" data-id="5090a267" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-large">Get Free Estimate</h2>		</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-22e014d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="22e014d" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-eaa998a" data-id="eaa998a" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-aa43847" data-id="aa43847" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-4b88b8c3 elementor-widget elementor-widget-button" data-id="4b88b8c3" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-size-md" role="button">
						<span class="elementor-button-content-wrapper">
							<span class="elementor-button-icon elementor-align-icon-right">
				<i aria-hidden="true" class="fas fa-hand-point-right"></i>			</span>
						<span class="elementor-button-text">Call now</span>
		</span>
					</a>
		</div>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7472ac9" data-id="7472ac9" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-bf1ade7 elementor-widget elementor-widget-text-editor" data-id="bf1ade7" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<a style="color: #FED700;" href="tel:+880-1617578013">+880 1617578013</a>					</div>
						</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c7c1121" data-id="c7c1121" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-fd4a60e elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="fd4a60e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-no">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9430472" data-id="9430472" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-14b29a5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="14b29a5" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-aaa184d" data-id="aaa184d" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-36cdc28 elementor-widget elementor-widget-heading" data-id="36cdc28" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">GET IN TOUCH</h2>		</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-93381ef elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="93381ef" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-83f4a2a" data-id="83f4a2a" data-element_type="column">
			<div class="elementor-column-wrap">
							<div class="elementor-widget-wrap">
								</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-f180dfc" data-id="f180dfc" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-2bd5226 elementor-widget elementor-widget-image" data-id="2bd5226" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
								<div class="elementor-image">
												<img decoding="async" width="768" height="512" src="wp-content/uploads/2021/04/3-768x512.jpg" class="attachment-medium_large size-medium_large wp-image-4398" >														</div>
						</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
<?php include('footer.php'); ?>