<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">
<div class="main-body">
		<div class="container-fluid">
		
		<div class="container">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-8 col-lg-8">
					
					
<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Chairman</h1>


<div class="card" >
 <img src="img/ch1.jpg" width="100%">
  <div class="card-body">
    <h4>Abdullah All Jayd</h4>
  </div>
</div>





<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Managing Director </h1>


<div class="card" >
 <img src="wp-content/uploads/2023/md jakaria.jpg" width="100%">
  <div class="card-body">
    <h4>Zakaria Hawladar</h4>
  </div>
</div>



<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Director</h1>


<div class="card" >
 <img src="wp-content/uploads/2018/07/director2a.jpg" width="100%">
  <div class="card-body">
    <h4>Retired Brigadier General Redwan</h4>
  </div>
</div>


<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Director</h1>


<div class="card" >
 <img src="wp-content/uploads/2018/07/directora.jpg" width="100%">
  <div class="card-body">
    <h4>Retired Army Comrade Captain Zakaria</h4>
  </div>
</div>






<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Director</h1>
<div class="card" >
 <img src="wp-content/uploads/2023/Foysal Ahmed.jpg" width="100%">
  <div class="card-body">
    <h4>Foysal Mahmud</h4>
   
  </div>
</div>



<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">General Manager</h1>
<div class="card" >
 <img src="img/eid.jpg" width="100%">
  <div class="card-body">
    <h4>S.M Eidrish Hossain</h4>
    <h4>(BSS BL Collage)</h4>
  </div>
</div>


<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Officer Call Center</h1>
<div class="card" >
 <img src="wp-content/uploads/2023/Mohima akhter.jpg" width="100%">
  <div class="card-body">
    <h4>Mohima Akter</h4>
  </div>
</div>

<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Officer Marketing</h1>
<div class="card" >
 <img src="wp-content/uploads/2023/AKM Shamim.jpg" width="100%">
  <div class="card-body">
    <h4>AKM Shamim</h4>
  </div>
</div>

<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Officer Marketing</h1>


<div class="card" >
 <img src="wp-content/uploads/2023/24/Musfiqur Rahman.jpg" width="100%">
  <div class="card-body">
    <h4>Musfiqur Rahman </h4>
  </div>
</div>

<h1 style="background-color: blue; padding: 5px; color: white; text-align: center;">Receptionist</h1>


<div class="card" >
 <img src="wp-content/uploads/2023/ajhora islam mishu.jpg" width="100%">
  <div class="card-body">
    <h4>Adhora islam mishu</h4>
  </div>
</div>



				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					
										
				</div>
			</div>
		</div>

				

		</div>		
</div>

<?php include('footer.php'); ?>



