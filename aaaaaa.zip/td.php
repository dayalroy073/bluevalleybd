<?php include('header.php');?>
<div class="main-body">
		
		<div class="container">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-12 col-lg-12">
<style type="text/css">
	.content-message {
    width: 100%;
    margin-top: 10px;
    border: 1px solid #eee;
    box-shadow: 0 0 7px 0px #ddd;
    padding: 7px 12px;
    text-align: justify;
    overflow: auto;
    margin-bottom: 10px
px
;
}
</style>
<?php $page=$_REQUEST['page']; ?>
<?php 
switch ($page) { case 'ourprofile':  ?>
<h1>Our Profile</h1>
<p>Evergreen Security  is a leading provider of security solutions in Bangladesh. We offer a complete range of security guard services including armed and unarmed security guards, security consulting, security training, and more. We are committed to providing the highest security and customer service possible. Our goal is to keep our clients safe and secure and to provide them with the peace of mind that comes from knowing they are protected by the best.

If you want to see our company’s complete profile please hit the below Link⇓</p>

<?php break; ?>

<!-- -----end of first case--- -->

<!-- ------Start case ------ -->
<?php case 'ourclient': ?>

<style type="text/css">
	ul {
    padding-left: 24px;
    list-style: none;
    list-style-image: url(https://shohagsecurity.com/wp-content/themes/sssltd/images/hand-right.png);
}
.content-message {
    width: 100%;
    margin-top: 10px;
    border: 1px solid #eee;
    box-shadow: 0 0 7px 0px #ddd;
    padding: 7px 12px;
    text-align: justify;
    overflow: auto;
    margin-bottom: 10px;
}
</style>
<div class="col-sm-12 col-md-8 col-lg-8">
					
					
<article id="post-118" class="post-118 page type-page status-publish hentry">

												
						<div class="entry-content">
							<div class="heading">
<h1 style="text-align: center;"><span style="color: #2d84fc;"><strong>♦ Our Client List ♦</strong></span></h1>
</div>
<div class="col-sm-12 col-md-6 col-lg-6">
<div class="content-message">
<ul class="list-styled">
<li>Hop Lun (Bangladesh) Ltd.</li>
<li>Hop Yick (Bangladesh) Ltd.</li>
<li>Siemens Group Bangladesh Ltd.</li>
<li>Welform Apparels Ltd.</li>
<li>Sabbir Traders Ltd.</li>
<li>Osman Interlinings Ltd.</li>
<li>OTL Doublegal Manufacturing Company Ltd.</li>
<li>Savar Industries Ltd.</li>
<li>Swanlon Com. Ltd.</li>
<li>Queen South Textile Mills Ltd.</li>
<li>DAEYU Bangladesh Ltd.</li>
<li>Radiance Fashion Ltd. (A Sister Concern of Radiance Group)</li>
<li>Jovian Sweater Ltd.</li>
<li>Agrani Trading Corporation Ltd</li>
<li>A.K Accessories Ltd.</li>
<li>Sky Line Group.</li>
<li>Bangla Japan Industries Ltd.</li>
<li>Myone Energy Ltd.</li>
<li>M. A. Automobiles Ltd.</li>
<li>Lakhsma Innerwear Ltd.</li>
<li>Scandex Knitwear Ltd.</li>
<li>East West Suiting Mills Ltd.</li>
<li>MyOne Electronics Ind. Ltd.</li>
<li>British Paints Ltd.</li>
<li>Dong A Leather Ltd.</li>
<li>Scandex Knitwear Ltd.</li>
<li>Desh Bangla General Hospital &amp; Diagnostic Center.</li>
<li>AIV.</li>
<li>Manvill Styles Ltd.</li>
<li>East West Ind Ltd.</li>
<li>AMA Washing Ltd.</li>
<li>Hyacinth Fabrics Mills Ltd.</li>
<li>Unifour Jacquard Designs Ltd.</li>
<li>Maliha Poly Tex Fiber Ind. Ltd.</li>
<li>SDS Industries Ltd.</li>
<li>S.islam Dream Real State Ltd.</li>
<li>IFL Factory Ltd.</li>
<li>Frame House Apparels Ltd.</li>
<li>BEPZA GM House.</li>
<li>RSF Group.</li>
<li>Quantum Janna.</li>
<li>Mum Real State.</li>
<li>Scandex Knitwear Ltd.</li>
<li>Spot Frame Apparels Ltd.</li>
<li>Kinsman Zipack Ltd.</li>
<li>Shantex (Pvt) Ltd.</li>
<li>Vigoror Ind Ltd.</li>
<li>Anando TV Ltd.</li>
<li>Yammy Food.</li>
<li>Merchandising Fashion.</li>
</ul>
</div>
</div>
						</div><!-- .entry-content -->
					</article>
				</div>
<?php break; ?>
<!-- ------End case ------ -->


<!-- ------Start case ------ -->
<?php case 'ouroffice': ?>
<style type="text/css">
	.heading h2 {
    color: #fff;
    border-left: 5px solid #FDCC09;
    background: #006FB7;
    text-transform: uppercase;
    font-weight: bold;
    margin: 10px 0px 10px 0px;
    padding: 13px 5px 8px 10px;
    font-size: 22px;
}
.content-message {
    width: 100%;
    margin-top: 10px;
    border: 1px solid #eee;
    box-shadow: 0 0 7px 0px #ddd;
    padding: 7px 12px;
    text-align: justify;
    overflow: auto;
    margin-bottom: 10px;
}
.margin-top {
    margin-top: 15px;
}
</style>
<div class="main-body">
		<div class="container-fluid">
		

					
					
<article id="post-120" class="post-120 page type-page status-publish hentry">

												
						<div class="entry-content">
							<div class="col-sm-12 col-md-6 col-lg-6">
<div class="heading">
<h2>Corporate Head Office</h2>
</div>
<div class="content-message office-address"><i class="fa fa-map-marker"></i><strong>Blue Valley Security service Limited.</strong><br>
Uttara Azampur Railgate 1230<br>

<i class="fa fa-phone"></i> +8801581638167<br>
<i class="fa fa-envelope"></i>  evergreencompany10@gmail.com<br>

<div class="ontent-message margin-top">
<div class="googlemap"><iframe onload="iframe_load();" id="preview" style="border: 0px; width: 100%; height: 300px;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=Azampur%20Railgate%20Jame%20Masjid%2C%20Road%20No%2020D%2C%20Dhaka%201230%2C%20Bangladesh&amp;key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe></div>
</div>
</div>

						</div><!-- .entry-content -->
					</article>
				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					
										
				</div>
			</div>
		</div>

				

	
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '0': ?>
<div class="container">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-12 col-lg-12">
				
							
						<div class="message-body">
						<h1>Security Guard Service</h1>
						<div class="content-message">
						
						
												
						<p>ক্লায়েন্টের কেমন ধরণের সিকিউরিটি গার্ড দরকার, সেই অনুযায়ী নিয়োগ বিজ্ঞপ্তি প্রকাশ করা হয়। আমাদের যে রিক্রুটিং টিম আছে, তার মাধ্যমে বাছাই করে সিকিউরিটি গার্ড নিয়োগ দেওয়া হয়। আমাদের টিম যে বিষয়গুলো দেখে সিকিউরিটি গার্ড নিয়োগ দেন, তা হলো; তার হাইট, ওয়েট, মেডিকেল রিপোর্ট, ফ্যামিলি ব্যাকগ্রাউন্ড ইত্যাদি পর্যালোচনা করা হয়। সাধারণত ক্লায়েন্টের চাহিদা থাকে ৫ ফুট ৪ ইঞ্চি থেকে ৫ ফুট ৯ ইঞ্চি উচ্চতার সিকিউরিটি গার্ড। সেই অনুযায়ী আমাদের গার্ড সিলেকশন করা হয়। এছাড়াও গার্ডের কোনো পুলিশ রেকর্ড আছে কি না, সে সব ডকুমেন্টশনও নিয়ে গার্ড নিয়োগ করা হয়। এরপর সফটওয়ারের মাধ্যমে ডাটা এন্ট্রি করার মাধ্যমে নিয়োগ প্রক্রিয়া সম্পূর্ণ করা হয়।&nbsp;</p>
<p>তারপর নিজেদের ট্রেনিং সেন্টারে বিশেষভাবে প্রশিক্ষণ দেওয়া হয়। ক্লায়েন্টের চাহিদা অনুযায়ী কখনো তাদের বাসা বাড়ি, কখনো বা ফ্যাক্টরি কিংবা অফিসে নিয়োগ দিতে হয়। সেইভাবেই তাদের প্রশিক্ষণ দেওয়া হয়। এরপর তাদের ক্লায়েন্টের কাছে হ্যান্ডওভার করা হয়। ক্লায়েন্টের প্রয়োজন অনুযায়ী সিকিউরিটি গার্ডটি নিয়মিত ডিউটি করতে শুরু করে। আপনার চাহিদা অনুযায়ী আমাদের কাছে সিকিউরিটি গার্ড অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো সিকিউরিটি গার্ড সরবরাহ করা হবে।&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p><img src="wp-content/uploads/2023/img.jpg" width="300px" height="280px;"></p>
<p>Depending on what type of security guard the client requires, the recruitment notice is released. The security guard is recruited by the recruiting team we have. One of the things that our team sees is the security guard being hired; His heights, weights, medical reports, family backgrounds, etc. are analyzed. Typically, clients demand a security guard of 5 feet 4 inches to 5 feet 9 inches in height. Accordingly, our guards are selected.<br>
Also, the guard has appointed with all the documentation whether the guard had any police records. The recruitment processes are then completed through data entry into the software. Then they were specifically trained in their training centers. Depending on the client’s needs, they have to be hired in their home, home or factory or office. They have trained accordingly. They are then handover to their client. As per the client’s requirement, the security guard begins to perform regular duty. You can order a security guard at your disposal. If you contact us, we will be provided with a security guard as needed.</p>
						</div>
					</div>
					
					
<div id="comments" class="comments-area">

			<h2 class="comments-title">
			4 thoughts on “Security Guard Service”		</h2>

		
		<ol class="comment-list">
					<li class="comment even thread-even depth-1 parent" id="comment-68">
				<div id="div-comment-68" class="comment-body">
				<div class="comment-author vcard">
			<img alt="" src="https://secure.gravatar.com/avatar/83e3ea09c3bd07ac585e8b71fc6e88c8?s=42&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/83e3ea09c3bd07ac585e8b71fc6e88c8?s=84&amp;d=mm&amp;r=g 2x" class="avatar avatar-42 photo" height="42" width="42" loading="lazy" decoding="async">			<cite class="fn">Sajb</cite> <span class="says">says:</span>		</div>
		
		<div class="comment-meta commentmetadata">
			<a href="https://shohagsecurity.com/security-guard/#comment-68">January 30, 2020 at 4:30 pm</a>		</div>

		<p>amader basar jonne  7.00 Am  theke  Rat 9 pm  porjonto  security guard lagbe . koto cost porbe ?/</p>

		<div class="reply"><a rel="nofollow" class="comment-reply-link" href="https://shohagsecurity.com/security-guard/?replytocom=68#respond" data-commentid="68" data-postid="3391" data-belowelement="div-comment-68" data-respondelement="respond" data-replyto="Reply to Sajb" aria-label="Reply to Sajb">Reply</a></div>
				</div>
				<ol class="children">
		<li class="comment odd alt depth-2" id="comment-70">
				<div id="div-comment-70" class="comment-body">
				<div class="comment-author vcard">
			<img alt="" src="https://secure.gravatar.com/avatar/45956efd0aa77f65e0b297a45bcae61d?s=42&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/45956efd0aa77f65e0b297a45bcae61d?s=84&amp;d=mm&amp;r=g 2x" class="avatar avatar-42 photo" height="42" width="42" loading="lazy" decoding="async">			<cite class="fn">Arman Habib</cite> <span class="says">says:</span>		</div>
		
		<div class="comment-meta commentmetadata">
			<a href="https://shohagsecurity.com/security-guard/#comment-70">February 5, 2020 at 5:36 am</a>		</div>

		<p>pls send me your number…</p>

		<div class="reply"><a rel="nofollow" class="comment-reply-link" href="https://shohagsecurity.com/security-guard/?replytocom=70#respond" data-commentid="70" data-postid="3391" data-belowelement="div-comment-70" data-respondelement="respond" data-replyto="Reply to Arman Habib" aria-label="Reply to Arman Habib">Reply</a></div>
				</div>
				</li><!-- #comment-## -->
		<li class="comment even depth-2" id="comment-71">
				<div id="div-comment-71" class="comment-body">
				<div class="comment-author vcard">
			<img alt="" src="https://secure.gravatar.com/avatar/45956efd0aa77f65e0b297a45bcae61d?s=42&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/45956efd0aa77f65e0b297a45bcae61d?s=84&amp;d=mm&amp;r=g 2x" class="avatar avatar-42 photo" height="42" width="42" loading="lazy" decoding="async">			<cite class="fn">Arman Habib</cite> <span class="says">says:</span>		</div>
		
		<div class="comment-meta commentmetadata">
			<a href="https://shohagsecurity.com/security-guard/#comment-71">February 5, 2020 at 5:37 am</a>		</div>

		<p>pls send me your number…</p>
<p>Arafatul Hoque Chowdhury<br>
Marketing Officer<br>
01705406701</p>

		<div class="reply"><a rel="nofollow" class="comment-reply-link" href="https://shohagsecurity.com/security-guard/?replytocom=71#respond" data-commentid="71" data-postid="3391" data-belowelement="div-comment-71" data-respondelement="respond" data-replyto="Reply to Arman Habib" aria-label="Reply to Arman Habib">Reply</a></div>
				</div>
				</li><!-- #comment-## -->
</ol><!-- .children -->
</li><!-- #comment-## -->
		<li class="comment odd alt thread-odd thread-alt depth-1" id="comment-69">
				<div id="div-comment-69" class="comment-body">
				<div class="comment-author vcard">
			<img alt="" src="https://secure.gravatar.com/avatar/3bb68f3ef3c30fae1ae126f6f5b688dd?s=42&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/3bb68f3ef3c30fae1ae126f6f5b688dd?s=84&amp;d=mm&amp;r=g 2x" class="avatar avatar-42 photo" height="42" width="42" loading="lazy" decoding="async">			<cite class="fn"><a rel="nofollow" href="http://www.shohagsecurity.com" class="url">Arafatul Hoque Chowdhury</a></cite> <span class="says">says:</span>		</div>
		
		<div class="comment-meta commentmetadata">
			<a href="https://shohagsecurity.com/security-guard/#comment-69">February 5, 2020 at 5:32 am</a>		</div>

		<p>pls send me your number…</p>
<p>Arafatul Hoque Chowdhury<br>
Marketing Officer<br>
01705406701</p>

		<div class="reply"><a rel="nofollow" class="comment-reply-link" href="https://shohagsecurity.com/security-guard/?replytocom=69#respond" data-commentid="69" data-postid="3391" data-belowelement="div-comment-69" data-respondelement="respond" data-replyto="Reply to Arafatul Hoque Chowdhury" aria-label="Reply to Arafatul Hoque Chowdhury">Reply</a></div>
				</div>
				</li><!-- #comment-## -->
		</ol><!-- .comment-list -->

		
	
	
		<div id="respond" class="comment-respond">
		<h2 id="reply-title" class="comment-reply-title">Leave a Reply <small><a rel="nofollow" id="cancel-comment-reply-link" href="/security-guard/#respond" style="display:none;">Cancel reply</a></small></h2><form action="https://shohagsecurity.com/wp-comments-post.php" method="post" id="commentform" class="comment-form"><p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> <span class="required-field-message">Required fields are marked <span class="required">*</span></span></p><p class="comment-form-comment"><label for="comment">Comment <span class="required">*</span></label> <textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required"></textarea></p><p class="comment-form-author"><label for="author">Name <span class="required">*</span></label> <input id="author" name="author" type="text" value="" size="30" maxlength="245" autocomplete="name" required="required"></p>
<p class="comment-form-email"><label for="email">Email <span class="required">*</span></label> <input id="email" name="email" type="text" value="" size="30" maxlength="100" aria-describedby="email-notes" autocomplete="email" required="required"></p>
<p class="comment-form-url"><label for="url">Website</label> <input id="url" name="url" type="text" value="" size="30" maxlength="200" autocomplete="url"></p>
<p class="comment-form-cookies-consent"><input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"> <label for="wp-comment-cookies-consent">Save my name, email, and website in this browser for the next time I comment.</label></p>
<p class="form-submit"><input name="submit" type="submit" id="submit" class="submit" value="Post Comment"> <input type="hidden" name="comment_post_ID" value="3391" id="comment_post_ID">
<input type="hidden" name="comment_parent" id="comment_parent" value="0">
</p><p style="display: none;"><input type="hidden" id="akismet_comment_nonce" name="akismet_comment_nonce" value="991bf825ae"></p><p style="display: none !important;"><label>Δ<textarea name="ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_1" name="ak_js" value="1677260178759"><script>document.getElementById( "ak_js_1" ).setAttribute( "value", ( new Date() ).getTime() );</script></p></form>	</div><!-- #respond -->
	
</div><!-- .comments-area -->
				
				<a href="#" rel="tag">Apartment Security Service</a>, <a href="#" rel="tag">Home Security service</a>, <a href="#" rel="tag">House Security Service</a>, <a href="#" rel="tag">list of security guard company in bangladesh</a>, <a href="#" rel="tag">personal security</a>, <a href="#" rel="tag">private security</a>, <a href="#" rel="tag">security service in bangladesh</a>, <a href="#" rel="tag">security services in dhaka</a><br>				
				</div>
				
				
				

				
				
				
					
					
					
				</div>
			</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '1': ?>
<div class="message-body">
						<h1>Close circuit camera</h1>
						<div class="content-message">
						
						
												
						<p>CC cameras, also known as closed-circuit television cameras, are an essential tool for security service companies. These cameras provide a reliable and effective way to monitor activity and deter criminal behavior, making them an important component of any comprehensive security system.</p>
<p>CC cameras work by capturing video footage of an area and transmitting it to a monitoring station. This allows security personnel to keep an eye on activity in real-time and respond quickly to any potential threats or incidents.</p>
<p>One of the primary advantages of CC cameras is their ability to cover large areas and provide a 24/7 surveillance presence. This makes them ideal for use in a variety of settings, including commercial buildings, public spaces, and residential properties.</p>
<p><img src="wp-content/uploads/2023/cc.png" width="300px" height="280px;"></p>
<p>In addition to providing real-time monitoring, CC cameras can also be used for forensic purposes. Video footage can be reviewed after an incident has occurred to identify suspects or provide evidence in legal proceedings.</p>
<p>When choosing CC cameras for security purposes, there are several factors to consider. The camera's resolution, field of view, and ability to operate in low-light conditions are all important considerations. It's also important to ensure that the cameras are installed in compliance with all applicable laws and regulations.</p>
<p>Overall, CC cameras are an important tool for security service companies looking to protect people and property. With their ability to provide real-time monitoring and surveillance, CC cameras offer a reliable and effective way to deter criminal behavior and respond quickly to potential threats.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '2': ?>
<div class="message-body">
						<h1>Drone</h1>
						<div class="content-message">
						
						
												
						<p>Drone</p>
<p>Drones are becoming an increasingly popular tool for security service companies to enhance their capabilities in protecting people and property. With the ability to fly high above an area and capture real-time video footage, drones provide a valuable tool for surveillance and reconnaissance.

One of the primary advantages of drones for security service companies is their ability to cover large areas quickly and efficiently. Drones can fly over buildings, parks, and other areas to monitor activity and identify potential threats. This makes them an ideal tool for security companies tasked with protecting large events or critical infrastructure.</p>
<p><img src="wp-content/uploads/2023/drone.png" width="300px" height="280px;"></p>
<p>In addition, drones can provide a unique perspective that is difficult to achieve with traditional security measures. With high-quality cameras and other sensors, drones can capture detailed images and video footage from a bird's-eye view. This can be especially useful for identifying potential vulnerabilities or suspicious activity.

Drones can also be used in conjunction with other security measures, such as ground patrols or surveillance cameras. By combining these tools, security service companies can create a comprehensive security system that covers all aspects of a property or event.

When choosing a drone for security purposes, there are several factors to consider. The drone's flight time, range, and camera capabilities are all important considerations, as is the ability to control the drone remotely. In addition, it's important to ensure that the drone is operated in compliance with all applicable laws and regulations.

Overall, drones are a valuable tool for security service companies looking to enhance their capabilities and protect people and property. With their ability to provide real-time video footage and cover large areas quickly and efficiently, drones offer a unique and valuable perspective for security professionals. As the technology continues to improve, it's likely that drones will become an even more important tool for security service companies in the years to come.



</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '3': ?>
<div class="message-body">
						<h1>Security In-charge</h1>
						<div class="content-message">
						
						
												
						<p>সিকিউরিটি ইনচার্জ<br>
একজন সিকিউরিটি ইনচার্জকে অবশ্যই আর্মি পার্সন হতে হবে, তা না হলে আমরা সিকিউরিটি ইনচার্জ হিসেবে নিই না। তার শিক্ষাগত যোগ্যতা হতে হবে ন্যুনতম ডিগ্রি পাশ। ১০-১২ বছরের সিকিউরিটি সুপারভাইজারের দায়িত্ব পালন করা হলেও তাকে সিকিউরিটি ইনচার্জ হিসেবে নেওয়া হয়। আমাদের টিম যে বিষয়গুলো দেখে সিকিউরিটি ইনচার্জ নিয়োগ দেন, তা হলো; তার হাইট, ওয়েট, মেডিকেল রিপোর্ট, ফ্যামিলি ব্যাকগ্রাউন্ড ইত্যাদি। এসবকিছু পর্যালোচনা করা হয় নিয়োগ দেওয়া হয়। এছাড়াও ইনচার্জের কোনো পুলিশ রেকর্ড আছে কি না, সে সব ডকুমেন্টশনও নিয়ে নিয়োগ করা হয়। এরপর সফটওয়ারের মাধ্যমে ডাটা এন্ট্রি করার মাধ্যমে নিয়োগ প্রক্রিয়া সম্পূর্ণ করা হয়। ক্লায়েন্টের সাথে যেমন চুক্তি হয়, সেই অনুযায়ী স্যালারি দেওয়া হয় সিকিউরিটি ইনচার্জকে। আপনার চাহিদা অনুযায়ী আমাদের কাছে সিকিউরিটি ইনচার্জ অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো সিকিউরিটি ইনচার্জ সরবরাহ করব।</p>
<p><img src="wp-content/uploads/2023/walki.jpg" width="300px" height="280px;"></p>
<p>A Security Incharge must be an Army Person, otherwise, we would not be considered a Security Incharge. His educational qualification must be a minimum degree. Although he served as a security supervisor for 8-12 years, he was taken as security in-charge.<br>
The minimum educational qualification of a Security Incharge must be Degree. In some cases, graduates are also taken. Also, the Incharge was appointed with all the documentation whether the Incharge had any police records. The recruitment process is then completed through data entry through the software. Then they were specifically trained in their training centers.<br>
If someone wants to be a security in-charge of an army surgent, You can order a security in-charge at your disposal. If you contact us, we will be provided with a security in-charge as needed.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ --><!-- ------Start case ------ -->
<?php case '4': ?>
<div class="message-body">
						<h1>Metal Detector</h1>
						<div class="content-message">
						
						
												
						<p>As security concerns continue to be at the forefront of everyone's minds, it's no surprise that metal detectors are becoming an increasingly common sight in public places. Whether it's airports, schools, or government buildings, metal detectors are a powerful tool in the fight against crime and terrorism.

For security service companies, metal detectors are an essential part of their arsenal. These companies are responsible for protecting people and property, and metal detectors are an effective way to prevent dangerous weapons and other prohibited items from entering a premises.

Metal detectors work by using an electromagnetic field to detect the presence of metal objects. When a metal object passes through the field, it disrupts the field and triggers an alarm. Metal detectors can be set up at entry points to screen people and their belongings, or they can be used in handheld form to scan individuals or specific areas.

There are a few key factors to consider when choosing a metal detector for security service companies. Firstly, the sensitivity of the detector is important, as it determines what types of objects can be detected. The size of the area to be covered is also a consideration, as larger areas may require multiple detectors or a more advanced system.

In addition, ease of use and durability are important factors to consider. Metal detectors must be easy for security personnel to use and maintain, and must be able to withstand frequent use in different environments.

One of the biggest advantages of metal detectors for security service companies is their ability to provide a visible deterrent to potential criminals or terrorists. The mere presence of metal detectors can deter would-be attackers and prevent dangerous situations from occurring.

Overall, metal detectors are a valuable tool for security service companies in the fight against crime and terrorism. With their ability to detect weapons and other prohibited items, metal detectors provide an added layer of protection that can help keep people and property safe. As security concerns continue to grow, it's likely that metal detectors will become an even more important part of security service companies' strategies.
<p><img src="wp-content/uploads/2023/metal.jpg" width="300px" height="280px;"></p>
<p>Bodyguard is used in English with the word gunman. However, the bodyguards who are licensed by the government are appointed as the gunmen. Basically, they are policemen. Also, retired Army Personnel are taken as gunmen. Except for the Army Parsons, ordinary people must have their firearms licenses to be gunmen. In that case, he was appointed as a gunman only after police verification and informing the police station.<br>
You can order a gunman at your disposal. If you contact us, we will be provided with a gunman as needed.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '5': ?>
<div class="message-body">
						<h1>Bodyguard Security Service</h1>
						<div class="content-message">
						
						
												
						<p>ইংরেজিতে বডিগার্ড শব্দটি দিয়েই দেহরক্ষীকে বোঝানো হয়। তবে সরকারিভাবে যেসব দেহরক্ষীর লাইসেন্স থাকে, তাদেরই বডিগার্ড হিসেবে নিয়োগ দেওয়া হয়। মূলত এরা পুলিশ সদস্য হয়ে থাকেন। এছাড়াও রিটায়ার্ড আর্মি পার্সনদের বডিগার্ড হিসেবে নেওয়া হয়। আর্মি পার্সন বাদে সাধারণ মানুষদের গানম্যান হতে হলে অবশ্যই তার আগ্নেয়াস্ত্রের লাইসেন্স থাকতে হয়। সেক্ষেত্রে পুলিশ ভ্যারিফিকেশন করিয়ে এবং থানায় ইনফর্ম করার পর তবেই তাকে গানম্যান হিসেবে নিয়োগ দেওয়া হয়। আপনার চাহিদা অনুযায়ী আমাদের কাছে গানম্যান অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো গানম্যান সরবরাহ করব।</p>
<p><img src="wp-content/uploads/2023/img.jpg" width="300px" height="280px;"></p>
<p>Bodyguard is used in English with the word gunman. However, the bodyguards who are licensed by the government are appointed as the gunman. Basically, they are policemen. Also, retired Army Personnel are taken as a gunman. Except for the Army Parsons, ordinary people must have their firearms licenses to be a bodyguard. In that case, he was appointed as a bodyguard only after police verification and informing the police station. You can order a bodyguard at your disposal. If you contact us, we will be provided with a bodyguard as needed.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '6': ?>
<div class="message-body">
						<h1>Road Protected Security Guard</h1>
						<div class="content-message">
						
						
												
						<p>যেকোনো ফ্যাক্টরি কিংবা কোম্পানির সামনে যদি ব্যস্ত সড়ক থাকে, তাহলে ফ্যাক্টরির সাধারণ কর্মীদের রাস্তা পেরুতে গিয়ে খুব বিপদে পড়তে হয়। বাস, গাড়ি, লরি পেরিয়ে রাস্তা পার হতে অনেকেই ভয় পায়। তাছাড়া আবাসিক এলাকাগুলোতে ভি আই পি দের গাড়ি চলাচলে যেন বিঘ্ন না ঘটে, সেখানে রোড প্রটেক্ট সিকিউরিটি গার্ডের প্রয়োজন হয়।</p>
<p>সাধারণত ক্লায়েন্টের চাহিদা থাকে ৫ ফুট ৪ ইঞ্চি থেকে ৫ ফুট ৯ ইঞ্চি উচ্চতার গার্ড। সেই অনুযায়ী আমাদের গার্ড সিলেকশন করা হয়। এছাড়াও গার্ডের কোনো পুলিশ রেকর্ড আছে কি না, সে সব ডকুমেন্টশনও নিয়ে গার্ড নিয়োগ করা হয়। এরপর সফটওয়ারের মাধ্যমে ডাটা এন্ট্রি করার মাধ্যমে নিয়োগ প্রক্রিয়া সম্পূর্ণ করা হয়।</p>
<p>তারপর নিজেদের ট্রেনিং সেন্টারে বিশেষভাবে প্রশিক্ষণ দেওয়া হয়। ক্লায়েন্টের চাহিদা অনুযায়ী কখনো তাদের বাসা বাড়ি, কখনো বা ফ্যাক্টরি কিংবা অফিসে নিয়োগ দিতে হয়। সেইভাবেই তাদের প্রশিক্ষণ দেওয়া হয়। এরপর তাদের ক্লায়েন্টের কাছে হ্যান্ডওভার করা হয়। ক্লায়েন্টের প্রয়োজন অনুযায়ী সিকিউরিটি গার্ডটি নিয়মিত ডিউটি করতে শুরু করে। আপনার চাহিদা অনুযায়ী আমাদের কাছে সিকিউরিটি গার্ড অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো সিকিউরিটি গার্ড সরবরাহ করব।</p>
<p><img src="wp-content/uploads/2023/img.jpg" width="300px" height="280px;"></p>
<p>If there is a busy road in front of any factory or company, the general staff of the factory is in danger of going to cross the road. Many are afraid of crossing buses, cars, lorries, and crossing roads. Besides, road safety guards are needed to prevent the movement of VIP vehicles in residential areas.</p>
<p>Clients are usually in need of a guard from 5 feet 4 inches to 5 feet 9 inches high. Accordingly, our guard is selected. Also, the guard has appointed with all the documentation whether the guard had any police records. The recruitment process is then completed through data entry through the software. Then they were specifically trained in their training centers. Depending on the client’s needs, they have to be employed in their home, home or factory or office. That is how they are trained. They are then handover to their client. As per the client’s requirement, the security guard begins to perform regular duty. You can order a security guard at your disposal. When contacting us, we will provide the security guard as needed.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '7': ?>
<div class="message-body">
						<h1>Security Service Equipment</h1>
						<div class="content-message">
						
						
												
						<p>সিকিউরিটি সংক্রান্ত কিছু ইন্সট্রুমেন্টস আছে, যা একটা সিকিউরিটি গার্ড কোম্পানির থাকা দরকার। যেমন: সি সি ক্যামেরা, ড্রোন, ওয়াকি টকি, মেটাল ডিটেক্টর, আর্চওয়ে গেট, প্রডাক্ট স্ক্যানার মেশিন, সিকিউরিটি সার্চলাইট, সিকিউরিটি টর্চলাইট ইত্যাদি। সিকিউরিটি সংক্রান্ত সব ইন্সট্রুমেন্টস, সিকিউরিটি কাজে ব্যবহৃত সমস্ত মেশিনারিজ সোহাগ লজিস্টিক এন্ড সিকিউরিটি সার্ভিস লিমিটেডে রয়েছে। এসব সিকিউরিটি মেশিনারিজ ব্যবহার করেই আমাদের কোম্পানি সিকিউরিটি সার্ভিস দেয়। সেই সাথে এই কোম্পানি সিকিউরিটির সলিউশনও দেয়। তাই সিকিউরিটি সার্ভিসের সাথে সংশ্লিষ্ট এই উপকরণগুলো কিনতে চাইলে আমাদের জানাতে পারেন। আমরা আপনার প্রয়োজনীয় জিনিস পাঠিয়ে দেওয়ার ব্যবস্থা করবো।</p>

<p><img src="wp-content/uploads/2023/img2.jpg" width="300px" height="280px;"></p>
<p>There are some security instruments that a security guard company needs to have. Such as CC Camera, Drone, Walkie Talkie, Metal Detector, Archway Gate, Product Scanner Machine, Security Searchlight, Security Flashlight, etc. All the instruments related to security, all the machinery used in the security work are in Shohag Logistics and Security Services Limited. Our company provides security services using these security machineries. The company also offers security solutions. So if you want to buy these materials related to the security service, let us know. We will arrange to send you what you need.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '8': ?>
<div class="message-body">
						<h1>Cash in Transit</h1>
						<div class="content-message">
						
						
												
						<p>একটা ফ্যাক্টরির টাকা যদি ফ্যাক্টরির এক অফিস থেকে অন্য অফিসে নিয়ে যাওয়ার দরকার পড়ে, কিংবা ব্যাংক থেকে হেড অফিসে টাকা আনার প্রয়োজন পড়ে, তবে ক্যাশ ইন ট্রানজিট গার্ডের প্রয়োজন পড়ে। ক্যাশ বা টাকা যখন কোনো গাড়িতে থাকে, তখন সেই টাকার একটা সিকিউরিটি দেওয়ার প্রয়োজন পড়ে। এক্ষেত্রে আর্মস গার্ডের প্রয়োজন হয়, অর্থাৎ এমন একজন গার্ডের প্রয়োজন হয়, যার কাছে লাইসেন্স করা অস্ত্র থাকে। মোট কথা, একজন গার্ড, যিনি অস্ত্র ধারন করে, গাড়ি নিয়ে এক জায়গা থাকে অন্য জায়গায় যাওয়ার পথে আপনার অর্থের নিরাপত্তা প্রদান করবেন, তিনিই ক্যাশ ইন ট্রানজিট হিসেবে কাজ করেন। আমাদের টিম যে বিষয়গুলো দেখে গার্ড নিয়োগ দেন, তা হলো; তার হাইট, ওয়েট, মেডিকেল রিপোর্ট, ফ্যামিলি ব্যাকগ্রাউন্ড ইত্যাদি। এসবকিছু পর্যালোচনা করা হয় নিয়োগ দেওয়া হয়। সাধারণত ক্লায়েন্টের চাহিদা থাকে ৫ ফুট ৪ ইঞ্চি থেকে ৫ ফুট ৯ ইঞ্চি উচ্চতার গার্ড। সেই অনুযায়ী আমাদের গার্ড সিলেকশন করা হয়। এছাড়াও গার্ডের কোনো পুলিশ রেকর্ড আছে কি না, সে সব ডকুমেন্টশনও নিয়ে গার্ড নিয়োগ করা হয়। এরপর সফটওয়ারের মাধ্যমে ডাটা এন্ট্রি করার মাধ্যমে নিয়োগ প্রক্রিয়া সম্পূর্ণ করা হয়।&nbsp; আপনার চাহিদা অনুযায়ী আমাদের কাছে ক্যাশ ইন ট্রানজিট গার্ড অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো ক্যাশ ইন ট্রানজিট গার্ড সরবরাহ করব।</p>
<p><img src="wp-content/uploads/2023/img.jpg" width="300px" height="280px;"></p>
<p>If you need to transfer money from a factory to another office, or you need to bring money from the bank to the head office, then cash in transit guard is required. When cash or money is in a car, it is necessary to provide security for that money. In this case, an Arms Guard is needed, that is, a Guard who has a licensed weapon. In total, a guard, who holds a weapon, has a car, will provide you with security for your money on the way to another location, which is the one that acts as cash in transit. One of the things our team looks for is the guard; His Heights, Weights, Medical Reports, Family Backgrounds, etc. All of these are reviewed and assigned. Clients are usually in need of a guard from 5 feet 5 inches to 5 feet 5 inches high. Accordingly, our guard is selected. Also, the guard has appointed with all the documentation whether the guard had any police records. The recruitment process is then completed through data entry through the software. You can order Cash In Transit Guard at your disposal. When contacting us, we will provide you with a cash in transit guard as needed.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '9': ?>
<div class="message-body">
						<h1>Security Consultancy</h1>
						<div class="content-message">
						
						
												
						<p>একটা ফ্যাক্টরি কীভাবে সিকিউরড করা হবে, তা নির্ধারণ করে সিকিউরিটি কনসালটেন্সি। নির্দিষ্ট কোনো ফ্যাক্টরিতে মালিকানা সিকিউরিটি থাকবে, নাকি কোম্পানি সিকিউরিটি থাকবে, ফ্যাক্টরি ভবনের কতোটুকু দূরত্বে বাউন্ডারির দেয়াল দেওয়া দরকার, দেয়ালের উচ্চতা কতটুকু হতে হবে, দেয়ালের উপরে কিংবা অন্য কোথায় কাঁটাতারের বেড়া দেওয়া প্রয়োজন; আপনার ফ্যাক্টরি তদারকি করে এর সবকিছু জানাবে সিকিউরিটি কনসালটেন্সি। পুরো ভবনকে নিরাপত্তার আওতাভুক্ত করতে কতগুলো সি সি ক্যামেরা বসাতে হবে, কয়জন ম্যান পাওয়ার লাগবে ফ্যাক্টরির সিকিউরিটির জন্য, আর্মস অর্থাৎ বন্দুক বা অন্যান্য আগ্নেয়াস্ত্র কয়টা লাগবে; এর সবকিছু সম্পর্কে ধারণা দেবে সিকিউরিটি কনসালটেন্সি। এছাড়াও কোম্পানির ওয়ারকাররা কীভাবে কাজ করবে, অফিসাররা কীভাবে তাদের নিয়ন্ত্রণ করবে, ভবনের অগ্নি নির্বাপন ব্যবস্থা কেমন হওয়া উচিত, ফ্যাক্টরির ভবনের নিরাপত্তার বিষয়গুলো দেখা, ওয়ার্কারদের মধ্যে গন্ডগোল দেখা দিলে কীভাবে থামাতে হবে ইত্যাদি সকল বিষয় সম্পর্কে আমাদের কোম্পানি সিকিউরিটি কনসালটেন্সি সেবা দেয়। মোটকথা, আপনার ফ্যাক্টরির এই ধরণের যেসব সমস্যা থাকে, তার সমাধান আমরা দিয়ে থাকি। আপনার ফ্যাক্টরির জন্য সিকিউরিটি কনসালটেন্সি প্রয়োজন হলে আমাদের সাথে যোগাযোগ করতে পারেন।</p>
<p><img src="wp-content/uploads/2023/img.jpg" width="300px" height="280px;"></p>
<p>Security consultancy determines how a factory will be secured. Whether a certain factory has proprietary security, or company security, the boundaries of the factory building should be provided at a distance, how high should the walls be, whether or not a barbed wire fence is required; Your factory will be monitored by a Security Consultancy. How many CC cameras need to be installed to cover the entire building, how many manpower will it require for factory security, how many weapons or guns and other firearms are required; Security consultancy will give an idea of everything. Also, our company provides security consultancy on how company workers work, how officers control them, how the building’s fire extinguishers should be looked at, factory safety issues, how to stop noise when there is a commotion among workers. In fact, we solve the problems your factory has. If you need a security consultancy for your factory, you can contact us.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '10': ?>
<div class="message-body">
						<h1>Commercial Investigation</h1>
						<div class="content-message">
						
						
												
						<p>ফ্যাক্টরিতে কতজন সিকিউরিটি গার্ড লাগবে, তা পরিষ্কার রাখতে কতজন ক্লিনার লাগবে, কী কী সিকিউরিটি মেশিনারিজ ও ক্লিনিং মেশিনারিজ দরকার, একটা ফ্যাক্টরি কীভাবে সিকিউরড করা হবে, ফ্যাক্টরিতে মালিকানা সিকিউরিটি থাকবে, নাকি কোম্পানি সিকিউরিটি থাকবে, ফ্যাক্টরি ভবনের কতোটুকু দূরত্বে বাউন্ডারির দেয়াল দেওয়া দরকার, দেয়ালের উচ্চতা কতটুকু হতে হবে, দেয়ালের উপরে কিংবা অন্য কোথায় কাঁটাতারের বেড়া দেওয়া প্রয়োজন; আপনার ফ্যাক্টরি তদারকি করে এর সবকিছু জানাবে কমার্শিয়াল ইনভেস্টিগেশন। পুরো ভবনকে নিরাপত্তার আওতাভুক্ত করতে কতগুলো সি সি ক্যামেরা বসাতে হবে, কয়জন ম্যান পাওয়ার লাগবে ফ্যাক্টরির সিকিউরিটির জন্য, আর্মস অর্থাৎ বন্দুক বা অন্যান্য আগ্নেয়াস্ত্র কয়টা লাগবে; এর সবকিছু সম্পর্কে ধারণা দেবে কমার্শিয়াল ইনভেস্টিগেশন। এছাড়াও কোম্পানির ওয়ারকাররা কীভাবে কাজ করবে, অফিসাররা কীভাবে তাদের নিয়ন্ত্রণ করবে, ভবনের অগ্নি নির্বাপন ব্যবস্থা কেমন হওয়া উচিত, ফ্যাক্টরির ভবনের নিরাপত্তার বিষয়গুলো দেখা, ওয়ার্কারদের মধ্যে গন্ডগোল দেখা দিলে কীভাবে থামাতে হবে ইত্যাদি সকল বিষয় সম্পর্কে আমাদের কোম্পানি কমার্শিয়াল ইনভেস্টিগেশন সেবা দেয়। মোটকথা, আপনার ফ্যাক্টরির এই ধরণের যেসব সমস্যা থাকে, তার সমাধান আমরা দিয়ে থাকি। আপনার ফ্যাক্টরির জন্য কমার্শিয়াল ইনভেস্টিগেশন প্রয়োজন হলে আমাদের সাথে যোগাযোগ করতে পারেন।</p>
<p><img decoding="async" class="aligncenter wp-image-3518 size-full" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Commercial-Investigation.png" alt="Commercial Investigation" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Commercial-Investigation.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Commercial-Investigation-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>How many security guards will be needed in the factory, how many cleaners will be needed to clean, what security machinery and cleaning machinery is needed, how to secure a factory, whether the factory has security or company security, whether the factory building is high, and how much is required to pay for the building. How much to be, whether on the wall or elsewhere in the fork Should be given era; Your factory will monitor it and report it to Commercial Investigation. How many CC cameras need to be installed to cover the entire building, how many manpower will it require for factory security, how many weapons or guns and other firearms are required; Commercial Investigation will give you an idea of everything. Also, our company provides Commercial Investigation Services on how the company’s workers work, how the officers control them, how the building’s fire extinguishers should be looked at, factory safety issues, how to stop a noise when the workers are involved. In fact, we solve the problems your factory has. If your factory requires a commercial investigation, you can contact us.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '11': ?>
<div class="message-body">
						<h1>Commercial Investigation</h1>
						<div class="content-message">
						
						
												
						<p>ফ্যাক্টরিতে কতজন সিকিউরিটি গার্ড লাগবে, তা পরিষ্কার রাখতে কতজন ক্লিনার লাগবে, কী কী সিকিউরিটি মেশিনারিজ ও ক্লিনিং মেশিনারিজ দরকার, একটা ফ্যাক্টরি কীভাবে সিকিউরড করা হবে, ফ্যাক্টরিতে মালিকানা সিকিউরিটি থাকবে, নাকি কোম্পানি সিকিউরিটি থাকবে, ফ্যাক্টরি ভবনের কতোটুকু দূরত্বে বাউন্ডারির দেয়াল দেওয়া দরকার, দেয়ালের উচ্চতা কতটুকু হতে হবে, দেয়ালের উপরে কিংবা অন্য কোথায় কাঁটাতারের বেড়া দেওয়া প্রয়োজন; আপনার ফ্যাক্টরি তদারকি করে এর সবকিছু জানাবে কমার্শিয়াল ইনভেস্টিগেশন। পুরো ভবনকে নিরাপত্তার আওতাভুক্ত করতে কতগুলো সি সি ক্যামেরা বসাতে হবে, কয়জন ম্যান পাওয়ার লাগবে ফ্যাক্টরির সিকিউরিটির জন্য, আর্মস অর্থাৎ বন্দুক বা অন্যান্য আগ্নেয়াস্ত্র কয়টা লাগবে; এর সবকিছু সম্পর্কে ধারণা দেবে কমার্শিয়াল ইনভেস্টিগেশন। এছাড়াও কোম্পানির ওয়ারকাররা কীভাবে কাজ করবে, অফিসাররা কীভাবে তাদের নিয়ন্ত্রণ করবে, ভবনের অগ্নি নির্বাপন ব্যবস্থা কেমন হওয়া উচিত, ফ্যাক্টরির ভবনের নিরাপত্তার বিষয়গুলো দেখা, ওয়ার্কারদের মধ্যে গন্ডগোল দেখা দিলে কীভাবে থামাতে হবে ইত্যাদি সকল বিষয় সম্পর্কে আমাদের কোম্পানি কমার্শিয়াল ইনভেস্টিগেশন সেবা দেয়। মোটকথা, আপনার ফ্যাক্টরির এই ধরণের যেসব সমস্যা থাকে, তার সমাধান আমরা দিয়ে থাকি। আপনার ফ্যাক্টরির জন্য কমার্শিয়াল ইনভেস্টিগেশন প্রয়োজন হলে আমাদের সাথে যোগাযোগ করতে পারেন।</p>
<p><img decoding="async" class="aligncenter wp-image-3518 size-full" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Commercial-Investigation.png" alt="Commercial Investigation" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Commercial-Investigation.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Commercial-Investigation-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>How many security guards will be needed in the factory, how many cleaners will be needed to clean, what security machinery and cleaning machinery is needed, how to secure a factory, whether the factory has security or company security, whether the factory building is high, and how much is required to pay for the building. How much to be, whether on the wall or elsewhere in the fork Should be given era; Your factory will monitor it and report it to Commercial Investigation. How many CC cameras need to be installed to cover the entire building, how many manpower will it require for factory security, how many weapons or guns and other firearms are required; Commercial Investigation will give you an idea of everything. Also, our company provides Commercial Investigation Services on how the company’s workers work, how the officers control them, how the building’s fire extinguishers should be looked at, factory safety issues, how to stop a noise when the workers are involved. In fact, we solve the problems your factory has. If your factory requires a commercial investigation, you can contact us.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '12': ?>
<div class="message-body">
						<h1>Cleaner</h1>
						<div class="content-message">
						
						
												
						<p>যেকোনো বাসা, ফ্যাক্টরি বা অফিস পরিষ্কার পরিচ্ছন্নতার জন্য ক্লিনিং সার্ভিসের প্রয়োজন। সোহাগ লজিস্টিক এন্ড সিকিউরিটি সার্ভিসের অঙ্গ প্রতিষ্ঠান ক্লিন বিডি দিচ্ছে সেরা ক্লিনিং সার্ভিস। এই প্রতিষ্ঠানের আছে উন্নত প্রশিক্ষণ কেন্দ্র আছে, যেখানে সমস্ত ধরণের পরিষ্কার পরিচ্ছন্নতার উপায় শেখানো হয়। এখানে তত্ত্বাবধায়ক, ক্লিনার্স এবং গার্ডেনারদের কেবলমাত্র পুঁথিগত প্রশিক্ষণই দেওয়া হয়, তা কিন্তু নয়। তারা হাতে কলমেও যথাযথ প্রশিক্ষণও পায়। প্র্যাক্টিক্যাল ট্রেনিংএর জন্য যা যা দরকার, অর্থাৎ বিভিন্ন ধরণের ফ্লোর, টয়লেট, ইউরিনাল, গ্লাস ইত্যাদি পরিষ্কার করানোর উপায়, এসব পরিষ্কার করতে যা যা ক্যামিকেল আর ইক্যুপমেন্ট লাগবে তা দেখানোর মাধ্যমে আমাদের এই কেন্দ্রটি পরিচালনা করছেন একটি ফুলটাইম ট্রেনার। কোনও সাইটে ক্লিনার নিয়োগ দেওয়ার আগে, তাকে অবশ্যই আমাদের প্রশিক্ষণ কেন্দ্রে প্রশিক্ষণের পর্যায়গুলো সফলভাবে শেষ করতে হয়। ৭ দিনের সফল প্রশিক্ষণের দেওয়ার পরেই, যার মধ্যে ক্লিনার হবার যোগ্যতা আছে, কেবল তাকেই কোনো প্রতিষ্ঠানে নিয়োগ দেওয়া হয়। ক্লায়েন্টের চাহিদা অনুযায়ী আমরা ক্লিনার দিয়ে থাকি। আপনার প্রয়োজন আমাদের কাছে ক্লিনার অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো ক্লিনার সরবরাহ করব।</p>
<p><img decoding="async" class="aligncenter wp-image-3537 size-full" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Home-cleaning-services.png" alt="Cleaner" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Home-cleaning-services.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Home-cleaning-services-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>Cleaning services are required for the cleanliness of any home, factory or office. Evergreen Security Services is a member of Clean BD offering the best cleaning services. This institute has advanced training centers, where all kinds of cleaning methods are taught. It is not only the caretakers, the cleaners and the gardeners but also the physical training provided. They also receive proper training on hand pen. What we need for practical training, in cleaning a variety of floors, toilets, urinals, etc. is running a full-time trainer. Before hiring a cleaner on a site, he or she must successfully complete the following training steps at our training center. Only after 5 days of successful training, which has the ability to become a cleaner, is the appointed to any institute. We provide cleaner as per the client’s demand. You can order a cleaner for us if you need. When contacting us, we will provide you with cleaner as needed.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '14': ?>
<div class="message-body">
						<h1>Cleaning Supervisor</h1>
						<div class="content-message">
						
						
												
						<p>একজন দক্ষ ক্লিনারের কয়েক বছরের অভিজ্ঞতা হলে তাকে ক্লিনিং সুপারভাইজার হিসেবে পদোন্নতি দেওয়া হয়। তারমানে অভিজ্ঞ লোক ছাড়া ক্লিনার সুপারভাইজার হিসেবে আমরা নিয়োগ দিই না। শুধু অভিজ্ঞতা থাকলেই চলবে না, ক্লিনার সুপারভাইজারকে অবশ্যই প্রশিক্ষণপ্রাপ্ত হতে হয়।&nbsp; এই প্রতিষ্ঠানের আছে উন্নত প্রশিক্ষণ কেন্দ্র আছে, যেখানে সমস্ত ধরণের পরিষ্কার পরিচ্ছন্নতার উপায় শেখানো হয়। এখানে ক্লিনার সুপারভাইজারদেরকে কেবলমাত্র বই পুস্তকে প্রশিক্ষণ দেওয়া হয়, তা কিন্তু নয়। তারা হাতে কলমেও যথাযথ প্রশিক্ষণও পায়। আমাদের এই কেন্দ্রটি পরিচালনা করছেন একটি ফুলটাইম ট্রেনার। কোনও সাইটে ক্লিনার সুপারভাইজারকে নিয়োগ দেওয়ার আগে, তাকে অবশ্যই আমাদের প্রশিক্ষণ কেন্দ্রে প্রশিক্ষণের পর্যায়গুলো সফলভাবে শেষ করতে হয়। ৭ দিনের সফল প্রশিক্ষণের দেওয়ার পরেই, যার মধ্যে ক্লিনিং সুপারভাইজার হবার যোগ্যতা আছে, কেবল তাকেই কোনো প্রতিষ্ঠানে নিয়োগ দেওয়া হয়। ক্লায়েন্টের চাহিদা অনুযায়ী আমরা ক্লিনার দিয়ে থাকি। আপনার প্রয়োজন অনুযায়ী আমাদের কাছে ক্লিনিং সুপারভাইজার অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো ক্লিনিং সুপারভাইজার &nbsp;সরবরাহ করব।</p>
<p><img decoding="async" class="aligncenter wp-image-3541 size-full" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Supervisor.png" alt="Cleaning Supervisor, Supervisor, Cleaner, Cleaner Supervisor, Cleaning company, cleaning agency, Cleaning, Cleaner" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Supervisor.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Supervisor-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>After several years of experience with a skilled cleaner, he was promoted to a cleaning supervisor. We do not hire cleaners without experienced people. Not just experience, cleaner supervisors must be trained. This institute has advanced training centers, where all kinds of cleaning methods are taught. Here, cleaner supervisors are trained not only in the book but also. They also receive proper training on hand pen. We have a full-time trainer operating this center. Before hiring a cleaner supervisor on a site, he or she must successfully complete the training stages at our training center. After 5 days of successful training, only those who have the qualification to become a Cleaning Supervisor are appointed to any institution. We provide cleaner as per the client’s demand. You can order a cleaning supervisor at our disposal. When contacting us, we will provide you with a cleaning supervisor as needed.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '16': ?>
<div class="message-body">
						<h1>Cleaning Incharge</h1>
						<div class="content-message">
						
						
												
						<p>ক্লিনিং সুপারভাইজার হিসেবে কয়েক বছরের অভিজ্ঞতা হলে তাকে ক্লিনিং ইনচার্জ হিসেবে পদোন্নতি দেওয়া হয়। ক্লিনিং এ অভিজ্ঞ হলেই ক্লিনার ইনচার্জ হিসেবে আমরা নিয়োগ দিই। শুধু অভিজ্ঞতা থাকলেই চলবে না, ক্লিনার ইনচার্জকে অবশ্যই প্রশিক্ষণপ্রাপ্ত হতে হয়।&nbsp; আমাদের প্রতিষ্ঠান ক্লিন বিডির আছে উন্নত প্রশিক্ষণ কেন্দ্র আছে, যেখানে একজন ক্লিনার কীভাবে পরিষ্কার পরিচ্ছন্নতার কাজ করবে, তা শেখানো হয়। আমাদের এই কেন্দ্রটি পরিচালনা করছেন একজন দক্ষ ট্রেনার। কোনও সাইটে ক্লিনার ইনচার্জকে নিয়োগ দেওয়ার আগে, তাকে অবশ্যই আমাদের প্রশিক্ষণ কেন্দ্রে প্রশিক্ষণের পর্যায়গুলো সফলভাবে শেষ করতে হয়। ৭ দিনের সফল প্রশিক্ষণের দেওয়ার পরেই, যার মধ্যে ক্লিনিং সুপারভাইজার হবার যোগ্যতা আছে, কেবল তাকেই কোনো প্রতিষ্ঠানে নিয়োগ দেওয়া হয়।</p>
<p>অভিজ্ঞতা ছাড়াও আমাদের টিম যে বিষয়গুলো দেখে ক্লিনার ইনচার্জ নিয়োগ দেন, তা হলো; তার কাজ করার দক্ষতা, উচ্চতা, ওজন, মেডিকেল রিপোর্ট, ফ্যামিলি ব্যাকগ্রাউন্ড ইত্যাদি। এসবকিছু পর্যালোচনা করে তবেই নিয়োগ দেওয়া হয়। এছাড়াও ইনচার্জের কোনো পুলিশ রেকর্ড আছে কি না, সে সব ডকুমেন্টশনও নিয়ে নিয়োগ করা হয়। এরপর সফটওয়ারের মাধ্যমে ডাটা এন্ট্রি করার মাধ্যমে নিয়োগ প্রক্রিয়া সম্পূর্ণ করা হয়।&nbsp; ক্লায়েন্টের সাথে যেমন চুক্তি হয়, সেই অনুযায়ী স্যালারি দেওয়া হয় ক্লিনার ইনচার্জকে। আপনার চাহিদা অনুযায়ী আমাদের কাছে ক্লিনার ইনচার্জ অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো ক্লিনার ইনচার্জ সরবরাহ করব।</p>
<p><img decoding="async" class="aligncenter size-full wp-image-3555" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Incharge-1.png" alt="Cleaning In-charge" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Incharge-1.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Incharge-1-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>After several years of experience as a cleaner supervisor, he was promoted to cleaning in-charge. We are employed as a cleaner in-charge when it comes to cleaning. Not only do you have the experience, but the cleaner in-charge must also be trained. Our company Clean Bid has an advanced training center, where a cleaner is taught how to perform a thorough cleaning. We have a skilled trainer operating this center. Before hiring a cleaner in-charge of a site, he must successfully complete the training phase at our training center. After 5 days of successful training, only those who have the qualification to become a Cleaning Supervisor are appointed to any institution.<br>
In addition to experience, one of the things our team employs when it comes to cleaner in-charge; His ability to work, height, weight, medical reports, family background, etc. Appointments are made only after reviewing all of these. Also, if the police in-charge has any records, they are appointed with all the documentation. The recruitment process is then completed through data entry through the software. According to the contract with the client, the salary is paid to the cleaner in charge. You can order cleaner in-charge to us as per your demand. When contacting us, we will provide you with a cleaner charge as needed.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '15': ?>
<div class="message-body">
						<h1>Floor Deep Cleaning</h1>
						<div class="content-message">
						
						
												
						<p>আমাদের কর্মীরা ফ্লোর স্ট্রাইপিংয়ের সব ধরণের বিষয়ে প্রফেশনালী প্রশিক্ষণপ্রাপ্ত। নিখুঁতভাবে সিলিং মেঝে রক্ষণাবেক্ষণ। ফ্লোর ফিনিশিং করে পরিষ্কার করার জন্য আমরা সর্বোচ্চ মানের পণ্য এবং সর্বাধিক আধুনিক সরঞ্জাম ব্যবহার করি। তাই আমরা মেঝের যত্নে কাজ করি ধারাবাহিকভাবে। ফ্লোর স্ক্র্যাবিং করার জন্য সর্বশেষতম ফ্লোর স্ক্র্যাবার অ্যাস্পেরিটি মেশিন “আইএমইসিপাওয়ার 154 (সি 43)” ব্যবহার করা হয়। সেই স্ট্যান্ডার্ড অনুযায়ী আনুষাঙ্গিক এবং বিশেষ ধরণের রাসায়নিক “পিনি / 527 এবং স্ট্রেট ক্লিন / 518 এবং শক্তিশালী স্ট্রিপার টেক অফ / 502” ফ্লোর স্ক্রাবিং করার সময় কেমিক্যাল হিসেবে ব্যবহৃত হয়। কালো হিলের চিহ্ন, জেদী দাগ এবং মেঝেতে আটকা পড়া মাটির তুলে ফেলতে এই ধরনের রাসায়নিক পদার্থ ভালো কাজ করে।</p>
<p><img decoding="async" class="aligncenter size-full wp-image-3562" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Floor-Cleaning.png" alt="" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Floor-Cleaning.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Floor-Cleaning-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>Our crews are professionally trained in all expects of floor stripping. Sealing cleaning, Floor finishing, and maintenance. AESPL uses only the highest quality Floor finishing products and the most modern equipment available. We take pride in producing consistently superior appearances in floor care. Floor Scrubbing will be done by the latest floor scrubber Asperity machine “IMEC_POWER 154 (C43)” with standard accessories and special Chemical “PINE/527 &amp; STRATE KLEEN/518 and powerful Stripper TAKE OFF/502” floor scrubbing chemical. This chemical exhibits deep cleaning action, which removes black heel marks, stubborn stain and trapped soil from Floor.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '16': ?>
<div class="message-body">
						<h1>Glass Cleaning</h1>
						<div class="content-message">
						
						
												
						<p>কাঁচ পরিষ্কার করার দুটি উপায়। <a rel="nofollow" href="https://en.wikipedia.org/wiki/Hydrophobic">হাইড্রোফোবিক</a> এবং <a rel="nofollow" href="https://en.wikipedia.org/wiki/Hydrophilic">হাইড্রোফিলিক</a>। এই দুই ক্ষেত্রেই পানির মাধ্যমে পরিষ্কার করা হয়। বাহ্যিক ও অভ্যন্তরীন এই ধরণের ক্ষেত্রে গ্লাস পরিষ্কার করা হয়।</p>
<p><strong>বাহ্যিক গ্লাস পরিষ্কার</strong></p>
<p>এক্সটেরিয়র গ্লাস ক্লিয়ারিংএর ক্ষেত্রে কাঁচ সাফাইয়ে কিছু জিনিষ প্রয়োজন হয়। ক্রিস্টাল সেট, টেলি প্লাস, ডাস্টার, ল্যাম্বস-উল, স্কিজে, স্ক্র্যাপার, হ্যাং দড়ি, বিশেষ গ্লাস ক্লিনিং কেমিক্যালস সহ সুরক্ষা বেল্ট দ্বারা আমাদের ক্লিনাররা গ্লাস পরিষ্কার করে।</p>
<p><strong>অভ্যন্তরীণ গ্লাস পরিষ্কার</strong></p>
<p>ইন্টিরিয়র গ্লাস পরিষ্কারের কাজে যেসব জিনিস লাগে তা হলো; সর্বজনীন কাঁচ পরিষ্কারের ক্রিস্টাল সেট, টেলিপ্লে, ডাস্টার, ল্যাম্বস-উল, স্কিজে, স্ক্র্যাপার, ঝুলন্ত দড়ি, বিশেষ গ্লাস ক্লিনিং কেমিক্যালস সহ সুরক্ষা বেল্ট। এসব উপকরণের মাধ্যমে আমাদের দক্ষ ক্লিনাররা কাঁচ পরিষ্কার করে থাকে। আপনার চাহিদা অনুযায়ী আমাদের কাছে গ্লাস ক্লিনার&nbsp; অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো গ্লাস ক্লিনার সরবরাহ করব।</p>
<p>আরও তথ্যের জন্য দয়া করে যোগাযোগ করুন&nbsp;<em><strong><a rel="nofollow" href="http://scleanbd.com/">scleanbd.com</a></strong></em>&nbsp;এ&nbsp;</p>
<p><img decoding="async" class="aligncenter wp-image-3570 size-full" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Glass-Cleaning.png" alt="Glass Cleaning, Glass Cleaner, Cleaner, Clean, Cleaning Solution, Cleaner Solution, Cleaning Service, Cleaner Service" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Glass-Cleaning.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Glass-Cleaning-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>The field of self-cleaning coatings on glass is divided into two categories:&nbsp;<a rel="nofollow" href="https://en.wikipedia.org/wiki/Hydrophobic">hydrophobic</a>&nbsp;and&nbsp;<a rel="nofollow" href="https://en.wikipedia.org/wiki/Hydrophilic">hydrophilic</a>. These two types of coating both clean themselves through the action of water.</p>
<p><strong>Exterior Glass Cleaning </strong></p>
<p>Glass cleaning will be done by the universal glass cleaning Kristal set, tele plus, Duster, Lambs-wool, Squeeze, Scrapper, Hanging Rope, Safety belt With Special Glass Cleaning Chemicals.&nbsp;&nbsp;&nbsp;</p>
<p><strong>Interior Glass Cleaning</strong></p>
<p>Glass cleaning will be done by the universal glass cleaning Kristal set, teleplays, Duster, Lambs-wool, Squeeze, Scrapper, Hanging Rope, Safety belt With Special Glass Cleaning Chemicals.</p>
<p>You can order a glass cleaner from us as per your demand. When contacting us, we will provide you with a glass cleaner as needed.</p>
<p>For more details please contact on<em><strong>&nbsp;<a rel="nofollow" href="http://scleanbd.com/">scleanbd.com</a></strong></em></p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '29': ?>
<div class="message-body">
						<h1>The Rat Control</h1>
						<div class="content-message">
						
						
												
						<p>বাসা বাড়িতে ইঁদুরের উৎপাত বাড়লে জীবন দুর্বিষহ হয়ে পড়ে। ইঁদুর প্রাণীটি ছোট হলেও&nbsp; ক্ষতির&nbsp; ব্যাপকতা&nbsp; অনেক। ইঁদুর&nbsp; শুধু&nbsp; আমাদের&nbsp; খাদ্যশস্য&nbsp; খেয়ে&nbsp; নষ্ট&nbsp; করে, তা&nbsp; নয়।&nbsp;এরা&nbsp;প্রয়োজনীয় সব জিনিসপত্র কেটে কুটে&nbsp; ধ্বংস&nbsp; করে। এছাড়াও&nbsp; এদের&nbsp; মলমূত্র,&nbsp; লোম&nbsp; খাদ্য&nbsp; দ্রব্যের&nbsp; সাথে&nbsp; মিশে&nbsp; টাইফয়েড,&nbsp; জন্ডিস,&nbsp; চর্মরোগ&nbsp; ও&nbsp; ক্রিমিরোগসহ&nbsp; ৬০&nbsp; ধরনের&nbsp; রোগ&nbsp; ছড়ায়।&nbsp; প্লেগ&nbsp; নামক&nbsp; মারাত্মক&nbsp; রোগের&nbsp; বাহক&nbsp; হচ্ছে&nbsp; ইঁদুর।&nbsp; ইঁদুর&nbsp; ঘরের&nbsp;খাবার&nbsp; নষ্ট&nbsp; ছাড়াও&nbsp; বৈদ্যুতিক&nbsp; তার, টেলিফোন&nbsp; তার&nbsp; ও&nbsp; কম্পিউটার&nbsp; যন্ত্র&nbsp; কেটে&nbsp; নষ্ট&nbsp; করে।</p>
<p>ইঁদুর নির্মূলের যথাযথ প্রয়োগ করে ইঁদুর নির্মুল করা যেতে পারে। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে, কোন কোন ক্যামিকেলের ব্যবহারে আর ইঁদুরের আক্রমণ হবে না।আপনার বাসায় বেড বাগের আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব।</p>
<p><img decoding="async" class="aligncenter size-full wp-image-3605" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Rat-control.png" alt="Rat Control Service " width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Rat-control.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Rat-control-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>Life becomes unbearable when rats grow at home. Although the rat is small, the damage is enormous. Not only do rats eat our food grains, but it’s also not. They cut and destroy all the necessary items. They also spread these diseases including typhoid, jaundice, dermatitis and cream disease in combination with their excreta, hair follicles. The rat is the carrier of a deadly disease called the plague. In addition to wasting food in the rat room, electric cables, telephone cables, and computer equipment were wasted.</p>
<p>Rats can be eliminated by proper application of rat elimination. Clean body paste controllers are thoroughly trained on the use of sophisticated chemicals. They understand very well how to clean, rats will not be attacked by the use of certain chemicals.</p>
<p>If your home invades a bed bug, let us know. When contacting us, we will provide you with a paste controller as needed.</p>
						</div>
					</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '17': ?>
<div class="message-body">
						<h1>Lorem ipsum under constraction</h1>
						<div class="content-message">
						
						
												
						<p>বাসা বাড়িতে ইঁদুরের উৎপাত বাড়লে জীবন দুর্বিষহ হয়ে পড়ে। ইঁদুর প্রাণীটি ছোট হলেও&nbsp; ক্ষতির&nbsp; ব্যাপকতা&nbsp; অনেক। ইঁদুর&nbsp; শুধু&nbsp; আমাদের&nbsp; খাদ্যশস্য&nbsp; খেয়ে&nbsp; নষ্ট&nbsp; করে, তা&nbsp; নয়।&nbsp;এরা&nbsp;প্রয়োজনীয় সব জিনিসপত্র কেটে কুটে&nbsp; ধ্বংস&nbsp; করে। এছাড়াও&nbsp; এদের&nbsp; মলমূত্র,&nbsp; লোম&nbsp; খাদ্য&nbsp; দ্রব্যের&nbsp; সাথে&nbsp; মিশে&nbsp; টাইফয়েড,&nbsp; জন্ডিস,&nbsp; চর্মরোগ&nbsp; ও&nbsp; ক্রিমিরোগসহ&nbsp; ৬০&nbsp; ধরনের&nbsp; রোগ&nbsp; ছড়ায়।&nbsp; প্লেগ&nbsp; নামক&nbsp; মারাত্মক&nbsp; রোগের&nbsp; বাহক&nbsp; হচ্ছে&nbsp; ইঁদুর।&nbsp; ইঁদুর&nbsp; ঘরের&nbsp;খাবার&nbsp; নষ্ট&nbsp; ছাড়াও&nbsp; বৈদ্যুতিক&nbsp; তার, টেলিফোন&nbsp; তার&nbsp; ও&nbsp; কম্পিউটার&nbsp; যন্ত্র&nbsp; কেটে&nbsp; নষ্ট&nbsp; করে।</p>
<p>ইঁদুর নির্মূলের যথাযথ প্রয়োগ করে ইঁদুর নির্মুল করা যেতে পারে। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে, কোন কোন ক্যামিকেলের ব্যবহারে আর ইঁদুরের আক্রমণ হবে না।আপনার বাসায় বেড বাগের আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব।</p>
<p><img src="wp-content/uploads/2023/img.jpg"></p>
<p>Life becomes unbearable when rats grow at home. Although the rat is small, the damage is enormous. Not only do rats eat our food grains, but it’s also not. They cut and destroy all the necessary items. They also spread these diseases including typhoid, jaundice, dermatitis and cream disease in combination with their excreta, hair follicles. The rat is the carrier of a deadly disease called the plague. In addition to wasting food in the rat room, electric cables, telephone cables, and computer equipment were wasted.</p>
<p>Rats can be eliminated by proper application of rat elimination. Clean body paste controllers are thoroughly trained on the use of sophisticated chemicals. They understand very well how to clean, rats will not be attacked by the use of certain chemicals.</p>
<p>If your home invades a bed bug, let us know. When contacting us, we will provide you with a paste controller as needed.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '24': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '24': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '26': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '27': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '29': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '30': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->

<!-- ------Start case ------ -->
<?php case '31': ?>
<div class="message-body">
						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Evergreen Security Service Ltd is committed to providing our clients with comprehensive security solutions to meet all their needs. We understand that pest control is an important aspect of maintaining a safe and healthy environment, and we offer high-quality pest control services to help you keep your property pest-free.
</p>
<img src="wp-content/uploads/2023/past.png" width="300px" height="280px;">
Pests can be a major problem in both residential and commercial properties, causing damage to buildings and property, as well as spreading diseases and allergens. Some common pests include rodents, ants, cockroaches, termites, bed bugs, and mosquitoes.
<p>
At Evergreen Security Service Ltd, we offer a range of pest control services to help you eliminate pests and prevent their return. Our experienced technicians use the latest techniques and technologies to identify and address pest infestations quickly and effectively.
</p>
Our pest control services include:

Inspection and assessment: We conduct a thorough inspection of your property to identify the types of pests present and the extent of the infestation.
<p>
Treatment: We develop a customized treatment plan based on the specific pest infestation in your property. Our treatment methods are safe and environmentally friendly, ensuring that your property remains pest-free without harming your health or the environment.
</p>
Prevention: We provide preventive measures to ensure that the pests do not return. We offer tips and advice on how to prevent future pest infestations and also provide ongoing maintenance services to ensure that your property remains pest-free.
<p>
At Evergreen Security Service Ltd, we are committed to providing our clients with high-quality pest control services. Our goal is to ensure that your property remains pest-free, safe, and healthy. Contact us today to schedule a pest control service for your property.</p>
</div>
</div>

<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '17': ?>
<div class="message-body">

						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '18': ?>
<div class="message-body">

						<h1>PEST CONTROL SERVICE</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean2.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '19': ?>
<div class="message-body">

						<h1>Glass Cleaning</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '20': ?>
<div class="message-body">

						<h1>Cleaning Service</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '21': ?>
<div class="message-body">

						<h1>Cleaning</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean2.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '22': ?>
<div class="message-body">

						<h1>Garden cleaning Service</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean2.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '23': ?>
<div class="message-body">

						<h1>Cleaning Equipment</h1>
						<div class="content-message">
<p>Blue Valley Security service Limited. understands the importance of maintaining a clean and hygienic environment, both in residential and commercial properties. A clean environment not only promotes good health and hygiene but also creates a positive and inviting atmosphere for all occupants.</p>
<p>That's why we offer comprehensive cleaning services to keep your property clean, hygienic, and free from any health hazards. Our experienced team of professional cleaners uses state-of-the-art cleaning equipment and techniques to provide superior cleaning services to our clients.</p>
	<img src="wp-content/uploads/2023/clean.jpg" width="300px" height="280px;">
<p>We offer a range of cleaning services to suit your specific needs and requirements, including residential cleaning, commercial cleaning, carpet cleaning, floor cleaning, and window cleaning. Our team of professional cleaners is trained to provide thorough and efficient cleaning services, ensuring that your property remains clean, hygienic, and inviting.</p>
<p>At Blue Valley Security service Limited., we are committed to using eco-friendly and non-toxic cleaning products to ensure the safety of our clients and the environment. Contact us today to schedule a cleaning service for your property, and experience the difference that a clean and hygienic environment can make.</p>
</div>
</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '24': ?>
<div class="message-body">
						<h1>Cleaning Chemicals</h1>
						<div class="content-message">
						
						
												
						<p>ক্লিনিং ক্যামিকেল</p>
<p>বাড়ি, অফিস ফ্যাক্টরি ক্লিনিং বা পরিষ্কার পরিচ্ছন্নতার জন্য কিছু ক্যামিকেলের প্রয়োজন হয়। নিচে এই সম্পর্কে লেখা হলো।</p>
<p>১। ফ্লোর ক্লিনিং ক্যামিকেল – কয়েক ধরনের<br>
২। গ্লাস ক্লিনিং কেমিকেল -কয়েক ধরনের<br>
৩। উড ক্লিনিং কেমিকেল – কয়েক ধরনের<br>
৪। টয়লেট ক্লিনিং কেমিকেল-কয়েক ধরনের<br>
৫। ফ্রেশনার – কয়েক ধরনের<br>
ইত্যাদি</p>
<p><img decoding="async" class="aligncenter size-full wp-image-3641" src="http://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Chemical.png" alt="Cleaning Chemicals" width="700" height="500" srcset="https://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Chemical.png 700w, https://shohagsecurity.com/wp-content/uploads/2020/02/Cleaning-Chemical-300x214.png 300w" sizes="(max-width: 700px) 100vw, 700px"></p>
<p>Some chemicals are needed for the home, office factory cleaning or cleaning. The following is written about:</p>
<ol>
<li>Floor Cleaning Chemical – A few types</li>
<li>Glass Cleaning Chemical – Various types</li>
<li>Wood Cleaning Chemical – A few types</li>
<li>Toilet Cleaning Chemicals-A few types</li>
<li>Freshener – A few types</li>
</ol>
<p>Etc.</p>
						</div>
					</div>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case 'securityprofile': ?>
<article id="post-3339" class="post-3339 page type-page status-publish hentry">

												
						<div class="entry-content">
							<div class="heading">
<h1 style="text-align: center;"><span style="color: #000000;">Our Security Profile</span></h1>
<p>Evergreen Security  Guard Service is one of the leading security guard service providers in Bangladesh. We provide highly trained and motivated security guards to our clients. Our security guards are well equipped with the latest security equipment and are capable of handling any security situation. We have a wide range of security services to choose from, so you can be sure that we have the right security solution for your needs. Contact us today to find out more about our security guard service.</p>
<p>If you want to see our security service profile please hit the below button</p>
</div>


<div class="is-content-justification-center is-layout-flex wp-container-1 wp-block-buttons">

</div>
						</div><!-- .entry-content -->
					</article>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case 'cleaningprofile': ?>
<article id="post-3339" class="post-3339 page type-page status-publish hentry">

												
						<div class="entry-content">
							<div class="heading">
<h1 style="text-align: center;"><span style="color: #000000;">Our Cleaning Profile</span></h1>
<p>Evergreen Security  Guard Service is one of the leading security guard service providers in Bangladesh. We provide highly trained and motivated security guards to our clients. Our security guards are well equipped with the latest security equipment and are capable of handling any security situation. We have a wide range of security services to choose from, so you can be sure that we have the right security solution for your needs. Contact us today to find out more about our security guard service.</p>
<p>If you want to see our security service profile please hit the below button</p>
</div>


<div class="is-content-justification-center is-layout-flex wp-container-1 wp-block-buttons">

</div>
						</div><!-- .entry-content -->
					</article>
<?php break; ?>
<!-- ------End case ------ -->
<!-- ------Start case ------ -->
<?php case '32': ?>

<?php break; ?>
<!-- ------End case ------ -->

<?php } ?>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php');?>