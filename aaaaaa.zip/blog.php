<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-126185c.css?ver=1675048395">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">




<div class="main-body">
		<div class="container-fluid">
		    
	<div class="main-body body-top">
		


<div class="message-body">
	<h2>Our Client</h2>
	<div class="clientlogo">
		<div id="thumbnail-slider">
				<div class="inner">
					<ul style="touch-action: pan-y; transition-property: transform; transition-timing-function: cubic-bezier(0.2, 0.88, 0.5, 1); transition-duration: 1500ms; transform: translateX(-760px);"><li class="" style="display: inline-block; height: 60px; width: 51px; z-index: 0;">
						<img width="51" height="60" src="../wp-content/uploads/2018/08/swanlon-logo.png" class="thumb img-responsive wp-post-image" alt="guard agency" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2018/08/swanlon-logo.png 51w, https://shohagsecurity.com/wp-content/uploads/2018/08/swanlon-logo-257x300.png 257w" sizes="(max-width: 51px) 100vw, 51px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li class="" style="display: inline-block; height: 60px; width: 100px; z-index: 0;">
						<img width="500" height="300" src="../wp-content/uploads/2020/01/unnamed-file.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/unnamed-file.png 500w, https://shohagsecurity.com/wp-content/uploads/2020/01/unnamed-file-300x180.png 300w" sizes="(max-width: 500px) 100vw, 500px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; height: 60px; width: 63px; z-index: 0;" class="">
						<img width="160" height="152" src="../wp-content/uploads/2018/08/hl_logo_con.jpg" class="thumb img-responsive wp-post-image" alt="security company" decoding="async" loading="lazy" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li class="" style="display: inline-block; height: 60px; width: 257px; z-index: 0;">
						<img width="856" height="200" src="../wp-content/uploads/2020/01/Tokai-Power.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/Tokai-Power.png 856w, https://shohagsecurity.com/wp-content/uploads/2020/01/Tokai-Power-300x70.png 300w, https://shohagsecurity.com/wp-content/uploads/2020/01/Tokai-Power-768x179.png 768w" sizes="(max-width: 856px) 100vw, 856px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; height: 60px; width: 50px; z-index: 0;" class="">
						<img width="50" height="60" src="../wp-content/uploads/2018/08/GM_logo_web-100x120_550x.png" class="thumb img-responsive wp-post-image" alt="security company" decoding="async" loading="lazy" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li class="" style="display: inline-block; height: 60px; width: 189px; z-index: 0;">
						<img width="1387" height="441" src="../wp-content/uploads/2020/01/AESERealEstate.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/AESERealEstate.png 1387w, https://shohagsecurity.com/wp-content/uploads/2020/01/AESERealEstate-300x95.png 300w, https://shohagsecurity.com/wp-content/uploads/2020/01/AESERealEstate-768x244.png 768w, https://shohagsecurity.com/wp-content/uploads/2020/01/AESERealEstate-1024x326.png 1024w" sizes="(max-width: 1387px) 100vw, 1387px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; height: 60px; width: 180px; z-index: 1;" class="active">
						<img width="180" height="60" src="../wp-content/uploads/2018/08/myone.png" class="thumb img-responsive wp-post-image" alt="security guard agency" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2018/08/myone.png 180w, https://shohagsecurity.com/wp-content/uploads/2018/08/myone-300x100.png 300w" sizes="(max-width: 180px) 100vw, 180px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; height: 60px; width: 192px; z-index: 0;" class="">
						<img width="1903" height="594" src="../wp-content/uploads/2020/01/scandex-knitwear-ltd.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/scandex-knitwear-ltd.png 1903w, https://shohagsecurity.com/wp-content/uploads/2020/01/scandex-knitwear-ltd-300x94.png 300w, https://shohagsecurity.com/wp-content/uploads/2020/01/scandex-knitwear-ltd-768x240.png 768w, https://shohagsecurity.com/wp-content/uploads/2020/01/scandex-knitwear-ltd-1024x320.png 1024w" sizes="(max-width: 1903px) 100vw, 1903px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 78px;" class="">
						<img width="78" height="60" src="../wp-content/uploads/2018/08/logo-1.png" class="thumb img-responsive wp-post-image" alt="security" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2018/08/logo-1.png 78w, https://shohagsecurity.com/wp-content/uploads/2018/08/logo-1-150x117.png 150w" sizes="(max-width: 78px) 100vw, 78px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 100px;" class="">
						<img width="500" height="300" src="../wp-content/uploads/2020/01/Untitled-13.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/Untitled-13.png 500w, https://shohagsecurity.com/wp-content/uploads/2020/01/Untitled-13-300x180.png 300w" sizes="(max-width: 500px) 100vw, 500px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 226px;" class="">
						<img width="226" height="60" src="../wp-content/uploads/2018/08/slogo.png" class="thumb img-responsive wp-post-image" alt="guard agency" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2018/08/slogo.png 226w, https://shohagsecurity.com/wp-content/uploads/2018/08/slogo-300x80.png 300w" sizes="(max-width: 226px) 100vw, 226px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 107.1px;" class="">
						<img width="357" height="200" src="../wp-content/uploads/2020/01/download.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/download.png 357w, https://shohagsecurity.com/wp-content/uploads/2020/01/download-300x168.png 300w" sizes="(max-width: 357px) 100vw, 357px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; height: 60px; width: 148px; z-index: 0;">
						<img width="148" height="60" src="../wp-content/uploads/2018/08/logso.png" class="thumb img-responsive wp-post-image" alt="Security Services" decoding="async" loading="lazy" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 60px;" class="">
						<img width="200" height="200" src="../wp-content/uploads/2018/09/final-1.png" class="thumb img-responsive wp-post-image" alt="security services" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2018/09/final-1.png 200w, https://shohagsecurity.com/wp-content/uploads/2018/09/final-1-150x150.png 150w" sizes="(max-width: 200px) 100vw, 200px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; height: 60px; width: 63.3708px; z-index: 0;">
						<img width="94" height="89" src="../wp-content/uploads/2018/08/506536_1f4e97d72be34855a5c69af1291825acmv2.jpg" class="thumb img-responsive wp-post-image" alt="best security company" decoding="async" loading="lazy" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 78.0911px;" class="">
						<img width="600" height="461" src="../wp-content/uploads/2018/09/WeChat-Image_20180609131224.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2018/09/WeChat-Image_20180609131224.png 600w, https://shohagsecurity.com/wp-content/uploads/2018/09/WeChat-Image_20180609131224-300x231.png 300w" sizes="(max-width: 600px) 100vw, 600px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 85.7143px;" class="">
						<img width="600" height="420" src="../wp-content/uploads/2020/01/Daeyu-Bangla-PNG-logo.png" class="thumb img-responsive wp-post-image" alt="Shohag security service client," decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/Daeyu-Bangla-PNG-logo.png 600w, https://shohagsecurity.com/wp-content/uploads/2020/01/Daeyu-Bangla-PNG-logo-300x210.png 300w" sizes="(max-width: 600px) 100vw, 600px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 60px;" class="">
						<img width="200" height="200" src="../wp-content/uploads/2020/01/dongjin-logo.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/dongjin-logo.png 200w, https://shohagsecurity.com/wp-content/uploads/2020/01/dongjin-logo-150x150.png 150w" sizes="(max-width: 200px) 100vw, 200px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0; height: 60px; width: 60px;" class="">
						<img width="225" height="225" src="../wp-content/uploads/2020/01/mk.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/mk.png 225w, https://shohagsecurity.com/wp-content/uploads/2020/01/mk-150x150.png 150w" sizes="(max-width: 225px) 100vw, 225px" style="cursor: pointer;">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0;">
						<img width="106" height="60" src="../wp-content/uploads/2018/08/1528086449.png" class="thumb img-responsive wp-post-image" alt="Akh Group" decoding="async" loading="lazy">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0;">
						<img width="200" height="200" src="../wp-content/uploads/2020/01/woolen-Wool-Ltd1.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/woolen-Wool-Ltd1.png 200w, https://shohagsecurity.com/wp-content/uploads/2020/01/woolen-Wool-Ltd1-150x150.png 150w" sizes="(max-width: 200px) 100vw, 200px">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0;">
						<img width="70" height="60" src="../wp-content/uploads/2018/08/ug_logo.png" class="thumb img-responsive wp-post-image" alt="guard agency" decoding="async" loading="lazy">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0;">
						<img width="900" height="480" src="../wp-content/uploads/2020/01/Simeens-Logo.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/Simeens-Logo.png 900w, https://shohagsecurity.com/wp-content/uploads/2020/01/Simeens-Logo-300x160.png 300w, https://shohagsecurity.com/wp-content/uploads/2020/01/Simeens-Logo-768x410.png 768w" sizes="(max-width: 900px) 100vw, 900px">									<a class="thumb" href="#"></a>
						</li><li style="display: inline-block; z-index: 0;">
						<img width="653" height="200" src="../wp-content/uploads/2020/01/sky-Line.png" class="thumb img-responsive wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://shohagsecurity.com/wp-content/uploads/2020/01/sky-Line.png 653w, https://shohagsecurity.com/wp-content/uploads/2020/01/sky-Line-300x92.png 300w" sizes="(max-width: 653px) 100vw, 653px">									<a class="thumb" href="#"></a>
						</li></ul>
				</div>
			<div id="thumbnail-slider-prev" class=""></div><div id="thumbnail-slider-next" class=""></div><div id="thumbnail-slider-pause-play"></div></div>
	
	</div>
</div>
<script>
	$(document).ready(function() {
			$('#LogoCarousel').carousel({
			interval: 300
			})
			
			$('#LogoCarousel').on('slid.bs.carousel', function() {
				//alert("slid");
			});
			
			
		});
	</script>		<div class="container-fluid">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-8 col-lg-8">
				
				
										<div class="message-body">
						<h2><a href="../the-use-of-drones-for-security-purpose/index.html">The Use Of Drones For Security Purpose</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../the-use-of-drones-for-security-purpose/index.html"></a>
						
						It is not very difficult to analyze the pros and cons of using drones for security services purposes. You might be surprised to find that there is no shortage of both negative and positive views about drone usage. On the one hand, some are against its use since they see it as a potential danger to human life. It has been widely observed that most of the terrorist attacks in the US and all over the world have been carried out by terrorists who used remote-controlled airplanes to carry out their attacks. The downsides of the drone are also many. Drones For Security The use of drones has been gradually increasing in Bangladesh keeping pace with the times. Whether it's for security or personal reasons, it's now a popular device. There are some legal restrictions on the use of drones in Bangladesh. But recently the Bangladesh government has brought some...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../the-use-of-cctv-camera-for-security-service/index.html">The Use of CCTV Camera for Security Service</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../the-use-of-cctv-camera-for-security-service/index.html"></a>
						
						CCTV camera for security service has been introduced globally, and this technology is becoming more popular. Many private individuals and organizations have their own security needs, but there are some significant disadvantages of using a CCTV camera system. These are defined in two categories, short-term and long-term advantages. We will discuss both of these aspects in this article. Short-term advantages of using a CCTV camera for security service are many. It helps to monitor and control the security situation. It acts as a deterrence for criminals and helps increase security coverage. When a crime occurs, the first thing that the police station would do is investigate the place. But if a CCTV camera is installed, you can easily see the face and other important information of the criminal through the camera. You will be able to identify the criminal by checking the CCTV footage. If you are not satisfied with...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../use-of-walkie-talkie-for-security-guard-service/index.html">Use Of Walkie Talkie For Security Guard Service</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../use-of-walkie-talkie-for-security-guard-service/index.html"></a>
						
						Walkie talkie for security service providers is one of the best equipment that you can buy if you are going to work in a place where having communication with your other agents or guards is very important. There are two types of communication that you can use here: the walkie talkie and the voice transmission. The walkie talkie is used for communication between two people. While the voice transmission is used to communicate with a third person. This will be very useful for those who have to go to a different location, inform another party about the event, or transfer something from one place to another. If you want to work as part of a security force in a specific area, this type of equipment is an essential component of your gear. It gives you the ability to contact others when needed and to do so in a secure manner....						</div>
					</div>
											<div class="message-body">
						<h2><a href="../use-of-archway-gate-advantages-and-disadvantages/index.html">Use of Archway Gate | Advantages and Disadvantages</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../use-of-archway-gate-advantages-and-disadvantages/index.html"></a>
						
						There is more to consider than just the aesthetic appeal when it comes to your house or organization's gate placement. While we may take it for granted that a gate is only there to provide the first entrance, it is essential to look at its other features. For instance, an archway offers a more secure entryway because it restricts the driveway directly in front of the gate. Also, when the archway is well-planned, landscaping and materials can have a definite impact on its performance. Therefore, it is essential to understand the aesthetic benefits of the archway and its practical and security aspects. Archway-Gate Advantages of Archway Gate There are numerous advantages to be gained from the use of the archway. One of the most common is direct access to the main door of your house. With an archway gate installed, you can save space by having the entrance directly in...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../the-uses-of-security-flashlights-in-your-company/index.html">The Uses of Security Flashlights in Your Company</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../the-uses-of-security-flashlights-in-your-company/index.html"></a>
						
						Security-Flashlights | Photo Credit: Unsplash If you are a business owner and want to be extra careful, you should consider using a security flashlight or a security guard with a flashlight on your premises. It is a simple way for you to make your customers feel safe in your establishment, and it also provides them with enough illumination that they do not feel any threat. One thing that you need to keep in mind is the location of your company. The area should be clear for you to do all the necessary business that you need to do. You can choose to place the flashlight in the middle of your business, or you can set it at different places around the building so that customers can easily see where they should go. Once you have made your mind about which location to place the security flashlight, you should choose your...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../lady-cleaner-service-to-clean-your-home-or-organization/index.html">Lady Cleaner Service to Clean Your Home or Organization</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../lady-cleaner-service-to-clean-your-home-or-organization/index.html"></a>
						
						Lady-Cleaner-Service Are you looking for a lady cleaner service to come and mop up your floors? There are many ways that your home can be cleaned and this includes being able to use the service whenever you feel like having it. In addition to this, if you want your house to look great, you may need to get the help of a professional to do it. This is very important because cleaning your home will require that you do more than just sweep the floor and dry the windows. When you go into the rooms that are not in use, you need to have your furniture and other items cleaned as well. By having a lady cleaner service come in regularly, you will be able to enjoy the benefits of having your home well maintained while allowing you to work from home as well. Benefits Of Professional Cleaning Service One...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../security-guard-whistle/index.html">Security Guard Whistles – Basic Information</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../security-guard-whistle/index.html"></a>
						
						Vector image by VectorStock / HappyDwiS A security guard whistle is a great tool to have in your arsenal of security equipment. This is an essential tool for every sentry. It will help alert you to an intrusion on the premises and is also a useful tool for training purposes and emergency situations. Some whistle devices are more suitable for specific types of applications, while others are suitable for general use. Purposes of Security Guard whistle First, let's discuss the general purposes for a security guard whistle. When the alarm is triggered, it is a good idea to get everyone indoors and then call the police or fire department. Some of the most common uses include a silent warning to let people know they need to evacuate a building, a loud warning to alert you that a burglary has occurred or an emergency signal to alert you to problems that...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../cleaning-service-guide/index.html">Cleaning Service – Key Facts That You Need To Know</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../cleaning-service-guide/index.html"></a>
						
						One would think picking a business cleaning service to take care of their facility would be a comparatively easy task. Most support chiefs of facilities, liable for look after the neatness and health of their structure, realize this is regularly not as straightforward on the grounds that it sounds. Such an office and its necessities direct the services required. the vibes of the office assume a major function in the achievement of the business, regardless of whether it's a store, trade foundation, or perhaps a medical clinic or factory. An unclean appearance always makes a nasty impression! With cleaning being a $292 billion dollar industry, there's an in-depth list of economic cleaning services, a number of which have decided to franchise. they vary from small, mid-size, and large, and everyone has their own category of services to supply. So, what are some things to seem for when making a decision?...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../security-guard-services/index.html">Essentials Of Security Guard Services</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../security-guard-services/index.html"></a>
						
						In the present relentless existence where security is turning into a genuine concern, security guard services turned out to be extremely fundamental. it had been before assumed that security was indispensable only for chiefs or a special class of people however presently even the plebeian requires a base measure of security. Significance of Gatekeeper Services Our general public is in desperate need of security services on account of the disturbing pace of robbery and other enemies of social exercises. Luckily, there are numerous organizations that give guardian services both for corporate and private security purposes. The main places that need these services are places of business, schools, shopping centers, strict spots, condos, at that point forward. gatekeeper services are basic in zones where intruding is normal. Because of the ascent in robberies, harm, and psychological oppressor assaults, there has been an impressive increment inside the utilization of gatekeeper services and...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../other-pest-killer/index.html">Other Pest Killer</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../other-pest-killer/index.html"></a>
						
						দিনশেষে কাজের জায়গা থেকে সবাই বাসায় ফেরে। ঘরে পোকামাকড়ের উপদ্রবের ফলে যদি ফিরতে হয় অগোছালো-অপরিষ্কার ঘরে, তাহলে ক্লান্তি যেন আরও বেড়ে যায়। এছাড়াও জিনিসপত্র তো নষ্ট হয়ই, নানা রকম অসুখ-বিসুখের ঝুঁকিও বেড়ে যায়। তাছাড়াও অফিস বা ফ্যাক্টরিকে পোকামাকড়মুক্ত রাখার কোনো বিকল্প নেই। পেস্ট কন্ট্রোল সার্ভিস দক্ষতার সাথে ফিউমিগেশন সার্ভিস, তেলাপোকা কন্ট্রোল, উইপোকা, ঘুন পোকা কন্ট্রোল, ইঁদুর কন্ট্রোল সার্ভিস, ফ্লাই কন্ট্রোল সার্ভিস, মশা কন্ট্রোল সার্ভিস, সংক্রামক রোগজীবাণুনাশক সার্ভিস, ছারপোকা দমন সার্ভিস দক্ষতার সাথে দিয়ে আসছে। আপনার বাসায় ক্ষতিকারক এসব পোকামাকড়ের আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব। At the end of the day, everyone returns home from work. If the insect infestation in the house is to return to the dirty-unclean house, then fatigue may increase. Also, things get wasted, the risk of various diseases increases. Also, there is no option to keep the office or factory free of insects. Pest control...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../the-rat-control/index.html">The Rat Control</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../the-rat-control/index.html"></a>
						
						বাসা বাড়িতে ইঁদুরের উৎপাত বাড়লে জীবন দুর্বিষহ হয়ে পড়ে। ইঁদুর প্রাণীটি ছোট হলেও&nbsp; ক্ষতির&nbsp; ব্যাপকতা&nbsp; অনেক। ইঁদুর&nbsp; শুধু&nbsp; আমাদের&nbsp; খাদ্যশস্য&nbsp; খেয়ে&nbsp; নষ্ট&nbsp; করে, তা&nbsp; নয়।&nbsp;এরা&nbsp;প্রয়োজনীয় সব জিনিসপত্র কেটে কুটে&nbsp; ধ্বংস&nbsp; করে। এছাড়াও&nbsp; এদের&nbsp; মলমূত্র,&nbsp; লোম&nbsp; খাদ্য&nbsp; দ্রব্যের&nbsp; সাথে&nbsp; মিশে&nbsp; টাইফয়েড,&nbsp; জন্ডিস,&nbsp; চর্মরোগ&nbsp; ও&nbsp; ক্রিমিরোগসহ&nbsp; ৬০&nbsp; ধরনের&nbsp; রোগ&nbsp; ছড়ায়।&nbsp; প্লেগ&nbsp; নামক&nbsp; মারাত্মক&nbsp; রোগের&nbsp; বাহক&nbsp; হচ্ছে&nbsp; ইঁদুর।&nbsp; ইঁদুর&nbsp; ঘরের&nbsp;খাবার&nbsp; নষ্ট&nbsp; ছাড়াও&nbsp; বৈদ্যুতিক&nbsp; তার, টেলিফোন&nbsp; তার&nbsp; ও&nbsp; কম্পিউটার&nbsp; যন্ত্র&nbsp; কেটে&nbsp; নষ্ট&nbsp; করে। ইঁদুর নির্মূলের যথাযথ প্রয়োগ করে ইঁদুর নির্মুল করা যেতে পারে। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে, কোন কোন ক্যামিকেলের ব্যবহারে আর ইঁদুরের আক্রমণ হবে না।আপনার বাসায় বেড বাগের আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব। Life becomes unbearable when rats grow at home. Although the rat is small, the damage is enormous. Not only do rats eat our...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../cockroach-control/index.html">Cockroach Control</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../cockroach-control/index.html"></a>
						
						তেলাপোকা সবচেয়ে প্রাচীন একটি ক্ষতিকর পোকা। তেলাপোকা সাধারণত উষ্ণ এবং স্যাঁতস্যাঁতে জায়গায় বংশ বৃদ্ধি করে। স্প্রে ব্যবহার করে অনেকেই তেলাপোকা নিধন করে। তবে স্প্রে ব্যবহারের আগে নিরাপত্তার দিক নির্দেশনা মেনে চলা উচিত। সেগুলো মানব শরীরের জন্যেও ক্ষতিকর। ঘরোয়া পদ্ধতিতে বেকিং সোডা ও চিনি, তেজপাতা, অ্যামোনিয়া মিশ্রণ, সাবান পানি , বোরিক অ্যাসিড ও ময়দা, গোলমরিচ, পেঁয়াজ, রসুন, গুঁড়ো সাবান, কফির তলানি , নিম: এর কড়া গন্ধ ও অন্যান্য উপাদান দিয়ে তেলাপোকা নিধন করা যায়। তবে ব্যস্ত সময়ে সবাই ভালোভাবে ঘর পরিষ্কার করতে পারে না। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে আর তেলাপোকার আক্রমণ হবে না। আপনার বাসায় তেলাপোকার আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব। The cockroach is the oldest harmful insect. The cockroach usually breeds in warm and damp places. Many people use sprays to kill the...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../mosquito-control/index.html">Mosquito Control</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../mosquito-control/index.html"></a>
						
						মশা থাকে না, এমন এলাকা খুব কমই আছে। মশার কামড়ে ডেঙ্গু, ম্যালেরিয়া, ফাইলেরিয়া সহ অনেক ধরনের জীবননাশকারী রোগ হয়। মশা নিধনের জন্য সাধারণত কয়েল কিংবা ইন্সেক্ট কিলার স্প্রে ব্যবহার করা হয়। এই দুটোই শরীরের জন্য খুবই ক্ষতিকারক। এছাড়া যখন পুরো এলাকা জুড়ে মশার আধিক্য বেড়ে যায়, তখন এসব তেমন কোনো কাজ করে না। তাই মশা নিয়ন্ত্রণ করার জন্য উল্লেখওগ্য ভূমিকা রাখে পেস্ট কন্ট্রোলাররা। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কী ব্যবহারে আর মশার উৎপাত কমবে।আপনার এলাকায় মশার আক্রমণ বেড়ে গেলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব। &nbsp; There are rarely any areas where mosquitoes are not Mosquito bites cause many life-threatening diseases, including dengue, malaria, filaria. Coil or injection killer spray is usually used to kill mosquitoes. Both of these are very harmful to the body. In addition, when mosquitoes increase...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../bed-bug-killer/index.html">Bed Bug Killer</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../bed-bug-killer/index.html"></a>
						
						বেড বাগগুলি এমন এক ধরণের পোকা যা সাধারণত মানুষের রক্ত ​​খায়। এগুলোর দংশনের ফলে ত্বক ফাটা, মনস্তাত্ত্বিক প্রভাব এবং অ্যালার্জির লক্ষণগুলো সহ একাধিক স্বাস্থ্য প্রভাব পড়তে পারে। বিছানা বাগ কামড়ালে ছোট ছোট ফোস্কা পড়ে এবং &nbsp;চুলকানি &nbsp;হতে পারে। বিছানা বাগগুলো বেশিরভাগ সময় অন্ধকার, লুকানো জায়গা; যেমনঃ বিছানার কিংবা সোফার গদি, বা কোনও দেয়ালের ফাটলগুলোতে থাকে। পরিষ্কার পরিচ্ছন্ন না থাকলে এগুলোর প্রকোপ বাড়ে। ব্যস্ত সময়ে সবাই ভালোভাবে ঘর পরিষ্কার করতে পারে না। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে আর বেড বাগের আক্রমণ হবে না।আপনার বাসায় বেড বাগের আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব। Bed bugs are a type of insect that normally eat human blood in the blood. These bites can have multiple health effects, including skin rashes, psychotic effects, and allergy symptoms. Bed bugs can fall...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../termite-control/index.html">Termite Control</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../termite-control/index.html"></a>
						
						টার্মাইট একটি ক্ষতিকর পোকা। সকল ধরণের প্রতিষ্ঠানের জন্য এটি একটি অত্যন্ত ক্ষতিকর কীট। যেসব অঞ্চলে মাটি অ্যাসিডযুক্ত সেখানে টার্মাইট আরও বেশি ধ্বংসাত্মক। বাংলাদেশে এটি ‘রেড লেট রাইট’ মাটিতে বেশি দেখা যায়, যা অ্যাসিডযুক্ত। এটি কাঠের দরজা এবং জানালা, ক্যাবিনেটস, আসবাব, কার্পেট, বৈদ্যুতিক ওয়্যারিং, নথি এবং কাপড়ের মতো বিভিন্ন মূল্যবান জিনিস নষ্ট করে ফেলে। ব্যস্ত সময়ে সবাই ভালোভাবে ঘর পরিষ্কার করতে পারে না। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে আর টার্মাইটের আক্রমণ হবে না।আপনার বাসায় টার্মাইটের আক্রমণ হলে আমাদের জানাতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো পেস্ট কন্ট্রোলার সরবরাহ করব। Termite is a harmful insect. It is a very harmful pest for all types of organizations. In areas where the soil is acidic, termites are even more destructive. In Bangladesh, it is more abundant in the 'Red Late Right' soil, which is acidic. It wastes...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../white-ants/index.html">White ants</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../white-ants/index.html"></a>
						
						সাদা পিঁপড়ে বাড়িতে সাদা পিঁপড়ের আক্রমণ হলে বাড়ির কাঠের ভিত নড়ে যায়। কারণ এরা কাঠ খেয়ে ফেলে। সাদা পিঁপড়ে প্রায় আমাদের সবারই একটা বড় সমস্যা। ঘরদোর যতই পরিস্কার করে রাখা হোক না কেন, এই পিঁপড়ের হাত থেকে রেহাই পাওয়া প্রায় অসম্ভব। বিশেষ করে কাঠ যেখানে থাকে, সেখান থেকে সাদা পিঁপড়ে যেতেই চায় না। বাজারে পিঁপড়ে মারার নানারকম ওযুধ কিনতে পাওয়া যায়। তবে এগুলোর বেশিরভাগেই ক্ষতিকর রাসায়নিক পদার্থ থাকায় তা পিঁপড়ের পাশাপাশি মানুষেরও, বিশেষ করে ছোট বাচ্চাদের শরীরের ক্ষতি করে। ঘর-বাড়ি সাদা পিঁপড়ে এবং অন্যান্য কীট-পতঙ্গের থেকে মুক্ত রাখতে হলে প্রথম প্রয়োজন প্রতিদিন ঘরের সব কোনা ঠিকমতো পরিস্কার রাখা। জলে কীটনাশক লিক্যুইড মিশিয়ে প্রতিদিন দু-বার করে ঘর মোছা প্রয়োজন। ব্যস্ত সময়ে সবাই ভালোভাবে ঘর পরিষ্কার করতে পারে না। ক্লিন বিডির পেস্ট কন্ট্রোলারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। তারা খুব ভালোভাবে বুঝতে পারে কীভাবে পরিষ্কার করলে আর সাদা পিঁপড়ার আক্রমণ হবে না। আপনার বাসায় সাদা পিঁপড়ের আক্রমণ হলে আমাদের...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../cleaning-chemicals/index.html">Cleaning Chemicals</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../cleaning-chemicals/index.html"></a>
						
						ক্লিনিং ক্যামিকেল বাড়ি, অফিস ফ্যাক্টরি ক্লিনিং বা পরিষ্কার পরিচ্ছন্নতার জন্য কিছু ক্যামিকেলের প্রয়োজন হয়। নিচে এই সম্পর্কে লেখা হলো। ১। ফ্লোর ক্লিনিং ক্যামিকেল - কয়েক ধরনের ২। গ্লাস ক্লিনিং কেমিকেল -কয়েক ধরনের ৩। উড ক্লিনিং কেমিকেল - কয়েক ধরনের ৪। টয়লেট ক্লিনিং কেমিকেল-কয়েক ধরনের ৫। ফ্রেশনার - কয়েক ধরনের ইত্যাদি Some chemicals are needed for the home, office factory cleaning or cleaning. The following is written about: Floor Cleaning Chemical - A few types Glass Cleaning Chemical - Various types Wood Cleaning Chemical - A few types Toilet Cleaning Chemicals-A few types Freshener - A few types Etc.						</div>
					</div>
											<div class="message-body">
						<h2><a href="../cleaning-instruments/index.html">Cleaning Instruments</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../cleaning-instruments/index.html"></a>
						
						ক্লিনিং ইন্সট্রুমেন্টস বাড়ি, অফিস ফ্যাক্টরি ক্লিনিং বা পরিষ্কার পরিচ্ছন্নতার জন্য কিছু উপকরণের প্রয়োজন হয়। এসব আবার কয়েকভাগে বিভক্ত। নিচে এই সম্পর্কে লেখা হলো। ক্লিনিং মেশিনারিজ হলো; &nbsp; &nbsp; &nbsp;১। ভ্যাকুয়াম ক্লিনার - কয়েক ধরনের &nbsp; &nbsp; &nbsp;২। স্ক্র্যাবার - কয়েক ধরনের &nbsp; &nbsp; &nbsp;৩। হাই প্রেশার - কয়েক ধরনের &nbsp; &nbsp; &nbsp;৪। ড্রাইয়ার- কয়েক ধরনের &nbsp; &nbsp; &nbsp;৫। গ্লাস ক্লিনার &nbsp; &nbsp; &nbsp;৬। গ্লাস স্কুইজি &nbsp; &nbsp; &nbsp; ৭। কাঠের আসবাব পোলিশ ক্লিনার &nbsp; &nbsp; &nbsp; ৮। রুম ফ্রেশনার &nbsp; &nbsp; &nbsp; ৯।কার্পেট ক্লিনার &nbsp; &nbsp; ১০। ড্রাইয়ার এবং ড্রাইয়ার সীট&nbsp; &nbsp; &nbsp; ১১।পেট স্টেইন রিমুভার&nbsp; &nbsp; &nbsp; ১২। স্টেইনলেস ষ্টীল ক্লিনার এবং ওয়াইপ&nbsp; &nbsp; &nbsp; ১৩। সিলভার ক্লিনার, টারনিশ রিমুভার, পোলিশ &nbsp; &nbsp; ১৪। রাবার ক্লিনিং গ্লোভ &nbsp; &nbsp; ১৫। টাইল, স্টোন, গ্রেনাইট&nbsp; ক্লিনার &nbsp; &nbsp; ১৬। ডিশ রেক, এবং ড্রেইনবোর্ড&nbsp; ক্লিনার ইত্যাদি ক্লিনিং ইনস্ট্রুমেন্টস হলো;&nbsp; &nbsp; &nbsp; &nbsp;১। ঝাড়ু &nbsp; &nbsp; &nbsp;২। লাঠি &nbsp; &nbsp; &nbsp;৩। বালতি আরও...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../window-cleaning/index.html">Window Cleaning</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../window-cleaning/index.html"></a>
						
						জানালা পরিষ্কার করার পদ্ধতি কিছুটা আলাদা। জানালা তো বটেই, কিছু কিছু দরজাতেও গ্লাস থাকে। শোকেসসহ সব ধরনের কাঁচ ও থাই গ্লাস পরিষ্কার করার ক্ষেত্রে লাগবে পানির সঙ্গে সামান্য পরিমাণ ভিনেগার বা অ্যামোনিয়া। ভিনেগার কিংবা অ্যামোনিয়া মেশানো পানিতে এক টুকরো স্পঞ্জ বা ফোম ভিজিয়ে পরিষ্কার করতে হবে। এবার পুরোনো পত্রিকার পাতা ভিনেগার আর পানির মিশ্রণে ভিজিয়ে ভালোভাবে মুছে নিলে কাঁচের চকচকে ভাব ফিরে আসবে। সুতি কাপড় দিয়ে পরিষ্কার করতে গেলে হিতে বিপরীত অবস্থা হতে পারে। কাপড়ের সূক্ষ্ম সুতা কাঁচের গায়ে লেপটে যায়। জানালার কাঁচে উজ্জ্বলতা আনতে সাদা ভিনেগার ব্যবহার করা উচিত। প্রতি এক গ্যালন পানিতে দুই টেবিল চামচ ভিনেগারই যথেষ্ট। স্প্রে বোতলে নিয়ে স্প্রে করে পেপার বা সূক্ষ্ম সুতার কাপড় দিয়ে মুছে নিতে হবে। জানালার কাঁচ ছাড়াও জানালায় যে কপাট থাকে, তার আনাচে কানাচে যে ময়লা থাকে, তা ভ্যাকুয়াম ক্লিনার দিয়ে পরিষ্কার করতে হয়। আমাদের ক্লিনারদের অত্যাধুনিক ক্যামিকেলের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়।&nbsp; আপনার চাহিদা অনুযায়ী আমাদের কাছে জানালা ক্লিনার&nbsp;...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../garden-cleaner/index.html">Garden Cleaner</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../garden-cleaner/index.html"></a>
						
						বারান্দায়, ছাদে, বাসার পাশের চিলতে জমিতে বাগান করতে ভালোবাসেন অনেকেই। কষ্টের এই বাগানে যখন ফুল, ফল বা সবজি গাছের বদলে মাথাচাড়া দিয়ে ওঠে আগাছা, কিংবা আনাড়ি হাতে বাগান করতে গিয়ে পোকামাকড়ের অত্যাচারে অতিষ্ঠ হয়ে পড়েছেন। সেক্ষেত্রে অনেকেই এই আগাছা দূর করতে রাসায়নিকের সাহায্য নেন। কিন্তু অনভিজ্ঞ হাতে রাসায়নিক ব্যবহার করাটা আপনার স্বাস্থ্য, গাছ অথবা মাটির জন্য ভালো নয়। আবার অনেকেই বাগান পরিষ্কার করার যে ঝক্কি, তা সামলানোর জন্য উপযুক্ত সময় পান না। সপ্তাহান্তে যেটুকু সময় পান, তাতে পরিবারকে সময় দিতেই চলে যায়। বাগানের কাজ করা আর হয়ে ওঠে না আলসেমি কাটিয়ে।&nbsp;&nbsp; সেক্ষেত্রে ক্লিন বিডি আপনাকে দিতে পারে যথাযত বাগান পরিষ্কার করার নিশ্চয়তা। আমাদের ক্লিনাররা উপযুক্ত ক্যামিক্যাল ও পরিষ্কারক উপকরণের মাধ্যমে&nbsp; দক্ষতার সাথে বাগান পরিষ্কার করে থাকে। আপনার চাহিদা অনুযায়ী আমাদের কাছে গার্ডেন ক্লিনার অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো গার্ডেন ক্লিনার সরবরাহ করব।&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Many people love to garden on the balcony, on the terrace, next...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../carpets-upholstery-cleaning/index.html">Carpets / Upholstery Cleaning</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../carpets-upholstery-cleaning/index.html"></a>
						
						কার্পেট পরিষ্কার করার জন্য যথাযথ ভ্যাকুয়ামিং করার কৌশলগুলো ভালোভাবে ক্লিনারদের শেখানো হয়। আমাদের কর্মীরা বহনযোগ্য এক্সট্র্যাক্টর এবং সর্বাধুনিক বাণিজ্যিক ভ্যাকুয়াম ব্যবহার করে। আমরা পুরানো এবং নতুন উভয় ধরণের উপকরণ এবং টেক্সটাইল যথাযথ যত্নের সাথে পরিষ্কার করি। কার্পেট পরিচ্ছন্ন করার সর্বশেষতম অ্যাডভান্স কার্পেট শ্যাম্পুয়ার মেশিন IMEC GENIUS 700, বিশেষ ড্রাই ফোম শ্যাম্পু ZEN FRESH ব্যবহার করা হয়। কার্পেট পরিষ্কার সময়ে কার্পেটের অভ্যন্তরে যে ধুলো থাকে, তা ভ্যাকুয়াম ক্লিনার টেনে নিয়ে আসে। কার্পেটে যদি ধুলোর সাথে পানিও থাকে, তাহলে পানিও টেনে নিয়ে আসে আমাদের কিছু ভ্যাকুয়াম। ভ্যাকুয়াম ক্লিনার, হাই প্রেশারের মতো আধুনিক যন্ত্র ব্যবহার করার পর তা ভারী ড্রাইয়ার দ্বারা শুকানো হয়। বিস্তারিত জানতে যোগাযোগ করুন আমাদের ওয়েবসাইট &nbsp;scleanbd.com&nbsp; All janitors are thoroughly schooled in proper vacuuming/shampooing techniques. Our crews utilize portable extractors and the latest in Commercial vacuum products. We also maintain up-to dare familiarity with proper care of both old and new materials and textiles. Carpet shampooing will be done...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../glass-cleaning/index.html">Glass Cleaning</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../glass-cleaning/index.html"></a>
						
						কাঁচ পরিষ্কার করার দুটি উপায়। হাইড্রোফোবিক এবং হাইড্রোফিলিক। এই দুই ক্ষেত্রেই পানির মাধ্যমে পরিষ্কার করা হয়। বাহ্যিক ও অভ্যন্তরীন এই ধরণের ক্ষেত্রে গ্লাস পরিষ্কার করা হয়। বাহ্যিক গ্লাস পরিষ্কার এক্সটেরিয়র গ্লাস ক্লিয়ারিংএর ক্ষেত্রে কাঁচ সাফাইয়ে কিছু জিনিষ প্রয়োজন হয়। ক্রিস্টাল সেট, টেলি প্লাস, ডাস্টার, ল্যাম্বস-উল, স্কিজে, স্ক্র্যাপার, হ্যাং দড়ি, বিশেষ গ্লাস ক্লিনিং কেমিক্যালস সহ সুরক্ষা বেল্ট দ্বারা আমাদের ক্লিনাররা গ্লাস পরিষ্কার করে। অভ্যন্তরীণ গ্লাস পরিষ্কার ইন্টিরিয়র গ্লাস পরিষ্কারের কাজে যেসব জিনিস লাগে তা হলো; সর্বজনীন কাঁচ পরিষ্কারের ক্রিস্টাল সেট, টেলিপ্লে, ডাস্টার, ল্যাম্বস-উল, স্কিজে, স্ক্র্যাপার, ঝুলন্ত দড়ি, বিশেষ গ্লাস ক্লিনিং কেমিক্যালস সহ সুরক্ষা বেল্ট। এসব উপকরণের মাধ্যমে আমাদের দক্ষ ক্লিনাররা কাঁচ পরিষ্কার করে থাকে। আপনার চাহিদা অনুযায়ী আমাদের কাছে গ্লাস ক্লিনার&nbsp; অর্ডার করতে পারেন। আমাদের কাছে যোগাযোগ করলে আমরা আপনার প্রয়োজনমতো গ্লাস ক্লিনার সরবরাহ করব। আরও তথ্যের জন্য দয়া করে যোগাযোগ করুন&nbsp;scleanbd.com&nbsp;এ&nbsp; The field of self-cleaning coatings on glass is divided into two categories:&nbsp;hydrophobic&nbsp;and&nbsp;hydrophilic. These two types of coating both clean...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../sofa-cleaning/index.html">Sofa Cleaning</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../sofa-cleaning/index.html"></a>
						
						যেসব সোফায় ফোম ফিক্সড থাকে, সেগুলো পরিষ্কার করতে হয় ভ্যাকুয়াম ক্লিনার নিয়ে। সোফা কেমন পরিষ্কার হবে, তা নির্ভর করে ভ্যাকুয়াম ক্লিনারের পাওয়ার বা এনার্জির ওপর। সিলিন্ড্রিক্যাল ক্লিনার ১৪০০ ওয়াট আর আপরাইট সিলিন্ড্রিক্যাল ১৩০০ ওয়াট হলে ভালো হয়। ভ্যাকুয়ামের একটা মোটরের ম্যানুয়ালের নির্দেশ অনুযায়ী ক্লিনারের অ্যাটাচমেন্ট ব্যবহার করতে হয়। আমাদের ক্লিনাররা এসব খুঁটি নাটি বিষয়গুলো সম্পর্কে জানেন। যেমন- সোফার কর্নারের ময়লা পরিষ্কার করার জন্য সরু মুখ ভ্যাকুয়াম ক্লিনার লাগে। আবার সোফার উপরিভাগ পরিষ্কারের জন্য ব্রাশযুক্ত ক্লিনার ভালো। আমাদের ক্লিনারদের এসব অত্যাধুনিক যন্ত্রের ব্যবহার সম্পর্কে পুঙ্খানুপুঙ্খভাবে ট্রেনিং দেওয়া হয়। আরও তথ্যের জন্য দয়া করে যোগাযোগ করুন&nbsp;scleanbd.com&nbsp;এ&nbsp; The sofas in which the foam is fixed have to be cleaned with a vacuum cleaner. How clean the sofa is depending on the power or energy of the vacuum cleaner. Cylindrical cleaner 1 watt and upright cylindrical 5 watts are better. Vacuum cleaner attachments need to be used as instructed in the manual of a...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../floor-deep-cleaning/index.html">Floor Deep Cleaning</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../floor-deep-cleaning/index.html"></a>
						
						আমাদের কর্মীরা ফ্লোর স্ট্রাইপিংয়ের সব ধরণের বিষয়ে প্রফেশনালী প্রশিক্ষণপ্রাপ্ত। নিখুঁতভাবে সিলিং মেঝে রক্ষণাবেক্ষণ। ফ্লোর ফিনিশিং করে পরিষ্কার করার জন্য আমরা সর্বোচ্চ মানের পণ্য এবং সর্বাধিক আধুনিক সরঞ্জাম ব্যবহার করি। তাই আমরা মেঝের যত্নে কাজ করি ধারাবাহিকভাবে। ফ্লোর স্ক্র্যাবিং করার জন্য সর্বশেষতম ফ্লোর স্ক্র্যাবার অ্যাস্পেরিটি মেশিন "আইএমইসিপাওয়ার 154 (সি 43)" ব্যবহার করা হয়। সেই স্ট্যান্ডার্ড অনুযায়ী আনুষাঙ্গিক এবং বিশেষ ধরণের রাসায়নিক "পিনি / 527 এবং স্ট্রেট ক্লিন / 518 এবং শক্তিশালী স্ট্রিপার টেক অফ / 502" ফ্লোর স্ক্রাবিং করার সময় কেমিক্যাল হিসেবে ব্যবহৃত হয়। কালো হিলের চিহ্ন, জেদী দাগ এবং মেঝেতে আটকা পড়া মাটির তুলে ফেলতে এই ধরনের রাসায়নিক পদার্থ ভালো কাজ করে। Our crews are professionally trained in all expects of floor stripping. Sealing cleaning, Floor finishing, and maintenance. AESPL uses only the highest quality Floor finishing products and the most modern equipment available. We take pride in producing consistently superior appearances in floor care. Floor Scrubbing will be done...						</div>
					</div>
											<div class="message-body">
						<h2><a href="../cleaning-incharge/index.html">Cleaning Incharge</a></h2>
						<div class="content-message">
						<!-- <img src="images/ChairmanTalukder.jpg" class="img-thumbnail message-image"/> -->
						
						<a href="../cleaning-incharge/index.html"></a>
						
						ক্লিনিং সুপারভাইজার হিসেবে কয়েক বছরের অভিজ্ঞতা হলে তাকে ক্লিনিং ইনচার্জ হিসেবে পদোন্নতি দেওয়া হয়। ক্লিনিং এ অভিজ্ঞ হলেই ক্লিনার ইনচার্জ হিসেবে আমরা নিয়োগ দিই। শুধু অভিজ্ঞতা থাকলেই চলবে না, ক্লিনার ইনচার্জকে অবশ্যই প্রশিক্ষণপ্রাপ্ত হতে হয়।&nbsp; আমাদের প্রতিষ্ঠান ক্লিন বিডির আছে উন্নত প্রশিক্ষণ কেন্দ্র আছে, যেখানে একজন ক্লিনার কীভাবে পরিষ্কার পরিচ্ছন্নতার কাজ করবে, তা শেখানো হয়। আমাদের এই কেন্দ্রটি পরিচালনা করছেন একজন দক্ষ ট্রেনার। কোনও সাইটে ক্লিনার ইনচার্জকে নিয়োগ দেওয়ার আগে, তাকে অবশ্যই আমাদের প্রশিক্ষণ কেন্দ্রে প্রশিক্ষণের পর্যায়গুলো সফলভাবে শেষ করতে হয়। ৭ দিনের সফল প্রশিক্ষণের দেওয়ার পরেই, যার মধ্যে ক্লিনিং সুপারভাইজার হবার যোগ্যতা আছে, কেবল তাকেই কোনো প্রতিষ্ঠানে নিয়োগ দেওয়া হয়। অভিজ্ঞতা ছাড়াও আমাদের টিম যে বিষয়গুলো দেখে ক্লিনার ইনচার্জ নিয়োগ দেন, তা হলো; তার কাজ করার দক্ষতা, উচ্চতা, ওজন, মেডিকেল রিপোর্ট, ফ্যামিলি ব্যাকগ্রাউন্ড ইত্যাদি। এসবকিছু পর্যালোচনা করে তবেই নিয়োগ দেওয়া হয়। এছাড়াও ইনচার্জের কোনো পুলিশ রেকর্ড আছে কি না, সে সব ডকুমেন্টশনও নিয়ে নিয়োগ করা হয়। এরপর সফটওয়ারের মাধ্যমে...						</div>
					</div>
										
				<nav aria-label="Page navigation example">
				  <ul class="pagination">
				  </ul></nav></div></div></div></div></div></div>

<?php include('footer.php'); ?>