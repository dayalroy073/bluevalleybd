<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-1227a2d.css?ver=1675022629">
<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/global3fa8.css">


<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend-legacy.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">
<link rel="stylesheet" type="text/css" href="wp-content/plugins/elementor/assets/css/frontend.min007f.css?ver=3.10.2">

<link rel="stylesheet" type="text/css" href="wp-content/uploads/elementor/css/post-37173fa8.css">

<div class="main-body">
		<div class="container-fluid">
		
		<div class="container">
			<div class="row margin-top">
				<div class="col-sm-12 col-md-8 col-lg-8">
					
					
<article id="post-122" class="post-122 page type-page status-publish hentry">

												
						<div class="entry-content">
									<div data-elementor-type="wp-page" data-elementor-id="122" class="elementor elementor-122">
						<div class="elementor-inner">
				<div class="elementor-section-wrap">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-defa53c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="defa53c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-cf1c14d" data-id="cf1c14d" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-877aea7 elementor-widget elementor-widget-heading" data-id="877aea7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-large">SECURITY SERVICES<br></h1>		</div>
				</div>
				<div class="elementor-element elementor-element-55ec70e elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="55ec70e" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="op.php?page=security">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Guard</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=1">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Lady Guard</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=2">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Supervisor</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=3">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Incharge</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=4">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Gunman</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=5">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Bodyguard</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=6">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Road Protect Security</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=7">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Equipment</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=8">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cash In Transit</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=9">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Security Consultancy</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=10">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Commercial Investigation</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=11">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Background Screening</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-83d441d" data-id="83d441d" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-77d7e57 elementor-widget elementor-widget-heading" data-id="77d7e57" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-large">CLEANING SERVICE<br></h1>		</div>
				</div>
				<div class="elementor-element elementor-element-7a7adba elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="7a7adba" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="op.php?page=12">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaner</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=13">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Lady Cleaner</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=14">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaning Supervisor</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=15">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaning Incharge</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=16">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Floor Cleaning</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=17">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Glass Cleaning</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=18">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Carpet Cleaning</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=19">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Window Cleaning</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=20">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Sofa Cleaning</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=21">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Garden Cleaning Service</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=22">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaning Equipment</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=23">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cleaning Chemical</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-1bc5891" data-id="1bc5891" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-87b974f elementor-widget elementor-widget-heading" data-id="87b974f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-medium">PEST CONTROL SERVICE</h1>		</div>
				</div>
				<div class="elementor-element elementor-element-ebb063d elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="ebb063d" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="op.php?page=24">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">White ants</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=25">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Termite control</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=26">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Bed bug killer</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=27">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Mosquito control</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=28">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Cockroach control</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=29">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Rat control</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=30">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Others pest killer</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=31">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Pest Control Equipment</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="op.php?page=32">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="far fa-hand-point-right"></i>						</span>
										<span class="elementor-icon-list-text">Pest Control Chemical</span>
											</a>
									</li>
						</ul>
				</div>
				</div>
						</div>
					</div>
		</div>
								</div>
					</div>
		</section>
									</div>
			</div>
					</div>
								</div><!-- .entry-content -->
					</article>
				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					
										
				</div>
			</div>
		</div>

				

		</div>		
</div>

	<?php include('footer.php'); ?>